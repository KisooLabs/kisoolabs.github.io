// Runs inside embedded claude.ai frames only.
//
// Why this exists: claude.ai detects iframe embedding (window.top !== window.self,
// a browser-native, non-spoofable signal) and renders a stripped "embedded mode"
// that never mounts its left sidebar (<aside class="dframe-sidebar">) -- so a panel
// inside AI Exchange has no chat-history navigation at all. The sidebar cannot be
// restored (window.top is non-configurable; header/Sec-Fetch spoofs were verified
// ineffective, 2026-07-17).
//
// The fix that works: claude.ai's /recents route DOES render fully inside the frame
// (search box + chat list; each item links to /chat/<id> and opens in-frame). This
// injects a small floating button that toggles the frame between the current chat
// and that history list -- giving back the "history tab" access the sidebar provided.
(function () {
  // Top-level claude.ai (a normal tab) already has the real sidebar: do nothing.
  if (window.top === window.self) return;
  if (!/(^|\.)claude\.ai$/.test(location.hostname)) return;

  var BTN_ID = 'cv-claude-history-btn';
  var STYLE_ID = 'cv-claude-history-style';
  var LIST_RE = /^\/(recents|chats)\b/;

  // Button strings follow the 🌐 app language (i18n.js is injected before
  // this file). Resolved from the browser first so the button never waits on
  // storage; re-resolved (and re-applied) once the stored language arrives.
  //
  // The hub's language lives in `aix_state`. (A second key, the vendor page's
  // `options`, was read alongside it while both pages existed; that page is
  // gone.)
  var LANG_KEY = 'aix_state';
  var I18N = globalThis.CrossVerifyI18N;
  var MSG = I18N.resolve('system', navigator.language).msg;

  function pickLanguage(store) {
    var v = store && store[LANG_KEY] && store[LANG_KEY].language;
    return v || 'system';
  }

  try {
    chrome.storage.local.get(LANG_KEY, function (obj) {
      MSG = I18N.resolve(pickLanguage(obj), navigator.language).msg;
      refreshCurrent();
    });
    // The hub switches language without reloading the page (so panels keep
    // their sessions) — this frame therefore never re-runs. Follow the change
    // over storage instead of waiting for a reload that will not come.
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== 'local' || !changes[LANG_KEY]) return;
      MSG = I18N.resolve(pickLanguage({ 'aix_state': changes[LANG_KEY].newValue }), navigator.language).msg;
      refreshCurrent();
    });
  } catch (e) { /* storage unavailable — keep the browser-language strings */ }

  function onList() { return LIST_RE.test(location.pathname); }

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    var css = ''
      + '#' + BTN_ID + '{'
      + 'position:fixed;top:12px;left:12px;z-index:2147483647;'
      + 'width:34px;height:34px;border-radius:9px;'
      + 'border:1px solid #d7d4cc;background:#fff;color:#2b2924;'
      + 'font-size:15px;line-height:1;cursor:pointer;'
      + 'display:flex;align-items:center;justify-content:center;'
      + 'box-shadow:0 1px 3px rgba(0,0,0,.12);'
      + 'transition:background .12s,border-color .12s,box-shadow .12s;'
      + '-webkit-font-smoothing:antialiased;padding:0;}'
      + '#' + BTN_ID + ':hover{border-color:#cc7a56;box-shadow:0 2px 8px rgba(0,0,0,.16);}'
      + '#' + BTN_ID + ':focus-visible{outline:2px solid #4f46e5;outline-offset:2px;}'
      + '#' + BTN_ID + '[data-on="1"]{background:#cc7a56;border-color:#cc7a56;color:#fff;}';
    var style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = css;
    (document.head || document.documentElement).appendChild(style);
  }

  function refreshState(btn) {
    var open = onList();
    btn.setAttribute('data-on', open ? '1' : '0');
    btn.setAttribute('aria-pressed', open ? 'true' : 'false');
    btn.title = open ? MSG.historyHide : MSG.historyShow;
    btn.setAttribute('aria-label', MSG.historyAria);
  }

  function ensureButton() {
    if (document.getElementById(BTN_ID)) return;
    ensureStyle();
    var btn = document.createElement('button');
    btn.id = BTN_ID;
    btn.type = 'button';
    btn.setAttribute('aria-label', MSG.historyAria);
    btn.textContent = '☰'; // ☰
    btn.addEventListener('click', function () {
      // Full same-origin navigation: claude.ai's SPA re-renders /recents (or the
      // fresh /new composer) and the content script re-runs on the new document.
      location.assign(onList() ? '/new' : '/recents');
    });
    refreshState(btn);
    document.documentElement.appendChild(btn);
  }

  function refreshCurrent() {
    var btn = document.getElementById(BTN_ID);
    if (btn) refreshState(btn);
  }

  ensureButton();
  var lastPath = location.pathname;

  // One observer covers both concerns cheaply: re-inject only when the button is
  // actually gone (so streaming responses don't trigger work every mutation), and
  // refresh the pressed state only when the SPA path actually changed. Reading
  // location.pathname off the router directly avoids depending on History API
  // patching, which Next.js's own router reference can slip past.
  var mo = new MutationObserver(function () {
    if (!document.getElementById(BTN_ID)) ensureButton();
    if (location.pathname !== lastPath) { lastPath = location.pathname; refreshCurrent(); }
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener('popstate', refreshCurrent);
})();
