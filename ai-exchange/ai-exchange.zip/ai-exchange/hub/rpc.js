// Hub side of the panel protocol. One namespace, one implementation.
//
// The old page ran two protocols in the same frames: ours (`cross-verify`) and
// the vendor's (`ai-exchange`), each with its own composer resolution. The
// vendor's resolver already read the `data-cv-input` stamp our agent produces,
// so it depended on our code while duplicating it. Deleting the vendor shell
// removes the second protocol; what is left is this file plus the receiving
// half in crossverify/agent.js, which is carried over unchanged.
//
// Timeouts are per action, and one TIMEOUT retry is allowed only for actions
// that are safe to repeat. Both were established on the old page after a long
// conversation made panel frames slow enough that a flat 8s deadline aborted
// whole exchanges; the reasoning is recorded in DECISIONS.md 2026-08-22.
(function (root, factory) {
  const api = factory();
  root.AixRpc = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const NS = 'cross-verify';

  // READ_CONVERSATION reads innerText per turn and each read forces a layout,
  // so it scales with conversation length. READ_RESPONSE and FILL touch one
  // node but on a large DOM. SEND spends up to 6.6s of its own budget polling
  // for the button and then for the new user turn that confirms the submit,
  // before it can reply at all.
  const TIMEOUT_MS = {
    READ_RESPONSE: 20000,
    READ_CONVERSATION: 30000,
    FILL: 20000,
    SEND: 15000
  };
  const TIMEOUT_DEFAULT_MS = 8000;

  // SEND is deliberately absent: its click may have landed even when the reply
  // did not arrive, so retrying it could submit the same prompt twice.
  const RETRY_ON_TIMEOUT = { READ_RESPONSE: true, READ_CONVERSATION: true, FILL: true };

  let seq = 0;

  function request(panel, action, data) {
    return new Promise(function (resolve, reject) {
      const id = 'aix-' + (++seq);
      const timer = setTimeout(function () {
        window.removeEventListener('message', onMsg);
        reject(new Error('TIMEOUT'));
      }, TIMEOUT_MS[action] || TIMEOUT_DEFAULT_MS);
      function onMsg(ev) {
        const m = ev.data;
        if (!m || m.source !== NS || m.type !== 'response' || m.id !== id) return;
        clearTimeout(timer);
        window.removeEventListener('message', onMsg);
        if (m.error) reject(new Error(m.error));
        else resolve(m.data);
      }
      window.addEventListener('message', onMsg);
      panel.frame.contentWindow.postMessage(
        { source: NS, type: 'request', id: id, action: action, data: data }, '*');
    });
  }

  function requestRetrying(panel, action, data) {
    return request(panel, action, data).catch(function (e) {
      if (!RETRY_ON_TIMEOUT[action] || e.message !== 'TIMEOUT') throw e;
      return request(panel, action, data);
    });
  }

  // Run one action across panels, settling every one instead of stopping at the
  // first rejection, so a failure keeps the identity of the panel it came from
  // and the caller can name who broke rather than only that something did.
  function each(panels, action, dataFor) {
    return Promise.all(panels.map(function (p) {
      const data = typeof dataFor === 'function' ? dataFor(p) : (dataFor || {});
      const call = RETRY_ON_TIMEOUT[action] ? requestRetrying : request;
      return call(p, action, data).then(
        function (result) { return { ok: true, id: p.id, panel: p, data: result }; },
        function (e) { return { ok: false, id: p.id, panel: p, error: e.message }; }
      );
    }));
  }

  // Fill every composer, and send only if every fill succeeded, so one panel
  // failing can never leave the others sent. The filled composers are left in
  // place on abort so the user can retry without retyping.
  //
  // textFor receives a panel and returns that panel's text, which is what lets
  // Exchange give each panel a different payload (the other panels' answers)
  // while broadcast gives them all the same one.
  function fillThenSend(panels, textFor, opts) {
    const options = opts || {};
    return each(panels, 'FILL', function (p) { return { text: textFor(p) }; })
      .then(function (fills) {
        const failed = fills.filter(function (r) { return !r.ok; });
        if (failed.length) return { phase: 'fill', failures: failed, sent: [] };
        if (options.autoSend === false) return { phase: 'filled', failures: [], sent: [] };
        return each(panels, 'SEND', {}).then(function (sends) {
          const sendFailed = sends.filter(function (r) { return !r.ok; });
          if (sendFailed.length) return { phase: 'send', failures: sendFailed, sent: [] };
          // SEND reports whether the thread actually grew a user turn, which
          // is a stronger claim than "a click happened" and stronger than "the
          // composer cleared" — a panel whose session has gone stale inside the
          // frame clears the composer and drops the message (2026-08-28).
          const notSent = sends.filter(function (r) { return !(r.data && r.data.sent); });
          return { phase: 'done', failures: [], notSent: notSent, sent: sends };
        });
      });
  }

  // Panels report their document.title upward because the hub cannot read a
  // cross-origin iframe's title. The sender is matched by window identity, which
  // is reliable only because panel elements are never recreated (see panels.js).
  function onTitle(resolvePanel, handler) {
    window.addEventListener('message', function (ev) {
      const m = ev.data;
      if (!m || m.source !== NS || m.type !== 'title') return;
      const panel = resolvePanel(ev.source);
      if (panel) handler(panel, m.title || '');
    });
  }

  // A panel reports every focus that lands inside it, with whether the user put
  // it there (a pointer or key went down in that frame just before). The hub
  // returns a focus reported without input to the composer (focus.js).
  function onFocus(resolvePanel, handler) {
    window.addEventListener('message', function (ev) {
      const m = ev.data;
      if (!m || m.source !== NS || m.type !== 'focus') return;
      const panel = resolvePanel(ev.source);
      if (panel) handler(panel, m.user === true);
    });
  }

  return { NS, TIMEOUT_MS, TIMEOUT_DEFAULT_MS, RETRY_ON_TIMEOUT, request, requestRetrying, each, fillThenSend, onTitle, onFocus };
});
