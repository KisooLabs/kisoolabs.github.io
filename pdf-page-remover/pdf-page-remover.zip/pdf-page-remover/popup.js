// src/popup.js — manual-mode popup controller.
'use strict';
const $ = (id) => document.getElementById(id);
const state = { url: '', bytes: null, filename: 'document.pdf', sizes: [], pages: 0, remove: new Set(), pageTexts: [] };

function showStatus(msg, isErr) { const s = $('status'); s.textContent = msg; s.className = isErr ? 'err' : ''; s.classList.remove('hidden'); }

function looksLikePdf(url, contentType, buf) {
  if (contentType && contentType.includes('pdf')) return true;
  if (/\.pdf(\?|#|$)/i.test(url)) return true;
  const b = new Uint8Array(buf.slice(0, 5));
  return b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46 && b[4] === 0x2d; // %PDF-
}

function fileAccessAllowed() {
  return new Promise((r) => { try { chrome.extension.isAllowedFileSchemeAccess(r); } catch (_) { r(false); } });
}

// Chrome's fetch() does NOT support the file: scheme — it always throws
// "Failed to fetch", even with "Allow access to file URLs" granted. XHR does.
// The popup is a normal document (unlike the service worker), so XHR is fine.
function readFileUrl(url) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'arraybuffer';
    // file:// reads report status 0 on success.
    xhr.onload = () => ((xhr.status === 0 || (xhr.status >= 200 && xhr.status < 300)) && xhr.response
      ? resolve(xhr.response)
      : reject(new Error('could not open the file')));
    xhr.onerror = () => reject(new Error('could not open the file'));
    xhr.send();
  });
}

async function loadActivePdf() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url) { showStatus('No active tab.', true); return false; }
  state.url = tab.url;
  const isFile = state.url.startsWith('file://');
  if (isFile && !(await fileAccessAllowed())) {
    // The toggle is genuinely off — the only case where the "Enable file
    // access" button is the right thing to show.
    showFileHelp();
    return false;
  }
  try {
    let buf, ct = '', cd = null;
    if (isFile) {
      buf = await readFileUrl(state.url);   // no headers on a file:// read
    } else {
      // Credentials matter only for authenticated web PDFs (e.g. JSTOR).
      const res = await fetch(state.url, { credentials: 'include' });
      if (!res.ok) { showStatus('This tab is not a PDF. Open a PDF, then click the icon.', true); return false; }
      ct = (res.headers.get('content-type') || '').toLowerCase();
      cd = res.headers.get('content-disposition');
      buf = await res.arrayBuffer();
    }
    if (!looksLikePdf(state.url, ct, buf)) {
      showStatus('This tab is not a PDF. Open a PDF, then click the icon.', true); return false;
    }
    state.bytes = new Uint8Array(buf);
    state.filename = PPR.parseFilename(cd, fallbackName(state.url));
    return true;
  } catch (e) {
    // File access is already on here (checked above) or it's a web URL — report
    // the real error rather than wrongly telling the user to enable file access.
    showStatus('Couldn\'t read the PDF (' + (e.message || e) + ').', true);
    return false;
  }
}

// Local files need the user's "Allow access to file URLs" toggle, which no API
// can flip for them. The best we can do is one button that jumps straight to
// this extension's details page (where that toggle lives) — collapsing "open
// chrome://extensions, find the extension, open Details" into a single click.
function showFileHelp() {
  $('status').classList.add('hidden');
  const fh = $('fileHelp');
  fh.classList.remove('hidden');
  const btn = $('fileAccessBtn');
  if (!btn.dataset.wired) {
    btn.dataset.wired = '1';
    btn.addEventListener('click', () => chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id }));
  }
}

function fallbackName(url) {
  try { const p = new URL(url).pathname.split('/').pop() || 'document'; return decodeURIComponent(p); }
  catch (_) { return 'document'; }
}

function buildCells() {
  const grid = $('grid'); grid.innerHTML = '';
  for (let i = 1; i <= state.pages; i++) {
    const t = document.createElement('div');
    t.className = 'thumb' + (state.remove.has(i) ? ' mark' : '');
    t.dataset.page = i;
    t.innerHTML = '<div class="page">' + i + '</div><span class="no">' + i + '</span>';
    t.addEventListener('click', () => toggle(i, t));
    grid.appendChild(t);
  }
}

async function renderGrid() {
  const grid = $('grid');
  let pdf = null;
  try {
    pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('lib/pdfjs/pdf.worker.min.js');
    pdf = await pdfjsLib.getDocument({ data: state.bytes.slice() }).promise;
    state.pages = pdf.numPages;
  } catch (e) {
    // fallback: use pdf-lib's page count, numbered chips only. No text layer,
    // so text-based cover detection can't run (URL presets still can).
    state.pages = state.sizes.length || 1;
    state.pageTexts = [];
    grid.classList.add('chip-fallback');
    buildCells();
    return;
  }
  buildCells();
  // Pull the first few pages' text for cover detection (cheap; covers are at
  // the front). Kept separate from thumbnail rendering, which stays lazy.
  state.pageTexts = await extractTexts(pdf, 3);
  const io = new IntersectionObserver((entries, obs) => {
    entries.forEach((en) => { if (en.isIntersecting) { obs.unobserve(en.target); drawThumb(pdf, en.target); } });
  }, { root: grid, rootMargin: '120px' });
  grid.querySelectorAll('.thumb').forEach((t) => io.observe(t));
}

async function extractTexts(pdf, maxPages) {
  const out = [];
  const n = Math.min(maxPages, pdf.numPages);
  for (let i = 1; i <= n; i++) {
    try { const page = await pdf.getPage(i); const tc = await page.getTextContent(); out.push(tc.items.map((it) => it.str).join(' ')); }
    catch (_) { out.push(''); }
  }
  return out;
}

async function drawThumb(pdf, cell) {
  try {
    const page = await pdf.getPage(+cell.dataset.page);
    const vp0 = page.getViewport({ scale: 1 });
    const scale = 150 / vp0.width; // ~150px wide thumbs
    const vp = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = vp.width; canvas.height = vp.height;
    await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
    const box = cell.querySelector('.page'); box.textContent = ''; box.appendChild(canvas);
  } catch (_) { /* leave the numbered placeholder */ }
}

function toggle(page, cell) {
  if (state.remove.has(page)) state.remove.delete(page); else state.remove.add(page);
  cell.classList.toggle('mark'); updateCount();
}
function quick(kind) {
  state.remove = new Set();
  if (kind === 'all') for (let i = 1; i <= state.pages; i++) state.remove.add(i);
  else if (kind === 'cover') state.remove.add(1);
  else if (kind === 'last') state.remove.add(state.pages);
  // 'clear' leaves the set empty
  $('grid').querySelectorAll('.thumb').forEach((t) => t.classList.toggle('mark', state.remove.has(+t.dataset.page)));
  updateCount();
}
function updateCount() {
  const rm = state.remove, keep = state.pages - rm.size, btn = $('btn'), hint = $('hint'), count = $('count');
  if (rm.size === 0) {
    count.innerHTML = 'Click pages to mark them for removal · all <b>' + state.pages + '</b> kept';
    btn.disabled = true; hint.className = 'hintline'; hint.textContent = 'Saves a new copy · original untouched';
  } else if (keep === 0) {
    count.innerHTML = '<span class="r">All ' + state.pages + ' pages selected</span>';
    btn.disabled = true; hint.className = 'hintline warn'; hint.textContent = 'Keep at least one page.';
  } else {
    const list = [...rm].sort((a, b) => a - b).join(', ');
    count.innerHTML = 'Removing <span class="r">' + rm.size + '</span> (p. ' + list + ') · <span class="k">' + keep + '</span> pages remain';
    btn.disabled = false; btn.textContent = 'Remove ' + rm.size + ' & download';
    hint.className = 'hintline'; hint.textContent = 'Saves a new copy · original untouched';
  }
}
function wireQuick() { $('quick').querySelectorAll('button').forEach((b) => b.addEventListener('click', () => quick(b.dataset.q))); }

// Resolve once the download reaches a terminal state (or a timeout). Keeping the
// popup open until then keeps the blob URL alive so Chrome can finish reading it.
function waitForDownload(id, timeoutMs = 30000) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (state) => { if (settled) return; settled = true; chrome.downloads.onChanged.removeListener(onChanged); clearTimeout(timer); resolve(state); };
    const onChanged = (delta) => {
      if (delta.id !== id || !delta.state) return;
      if (delta.state.current === 'complete') finish('complete');
      else if (delta.state.current === 'interrupted') finish('interrupted');
    };
    const timer = setTimeout(() => finish('timeout'), timeoutMs);
    chrome.downloads.onChanged.addListener(onChanged);
    // Guard against the download finishing before the listener was attached.
    chrome.downloads.search({ id }, (items) => {
      const it = items && items[0];
      if (it && (it.state === 'complete' || it.state === 'interrupted')) finish(it.state);
    });
  });
}

async function onRemove() {
  const btn = $('btn'); btn.disabled = true; const prev = btn.textContent; btn.textContent = 'Working…';
  const restore = () => { btn.disabled = false; btn.textContent = prev; };
  let url = null;
  try {
    const { bytes } = await PPR.removePages(state.bytes, [...state.remove]);
    // Download straight from the popup via a blob URL. The popup holds the
    // `downloads` permission, so the PDF never has to be handed to the background
    // service worker as a data: URL. That removes the MV3 failure mode where an
    // idle/evicted worker silently drops the save message (empty-tail
    // "Save failed:"). The JSTOR content script still uses the background path
    // because content scripts can't call chrome.downloads directly.
    url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
    const downloadId = await chrome.downloads.download({ url, filename: state.filename, saveAs: false, conflictAction: 'uniquify' });
    if (typeof downloadId !== 'number') throw new Error((chrome.runtime.lastError && chrome.runtime.lastError.message) || 'download was not created');
    const state2 = await waitForDownload(downloadId);
    if (state2 === 'interrupted') { URL.revokeObjectURL(url); showStatus('Save failed: download interrupted', true); restore(); return; }
    URL.revokeObjectURL(url);   // 'timeout' also lands here; small PDFs are done well before 30s
    showStatus('Saved to Downloads: ' + state.filename);
    setTimeout(() => window.close(), 500);
  } catch (e) {
    if (url) URL.revokeObjectURL(url);
    showStatus('Save failed: ' + (e && e.message ? e.message : e), true);
    restore();
  }
}
function reveal() { ['quick', 'grid', 'count', 'btn', 'hint'].forEach((id) => $(id).classList.remove('hidden')); $('status').classList.add('hidden'); }

function isJstorUrl(u) { return /^https?:\/\/(?:www\.)?jstor\.org\//i.test(u || ''); }

async function boot() {
  const ok = await loadActivePdf();
  if (ok) {
    // A PDF loaded — show ONLY the tool. No opt-in rows cluttering the view.
    $('file').textContent = state.filename;
    try { state.sizes = await PPR.readPageSizes(state.bytes); } catch (_) { state.sizes = []; }
    await renderGrid();
    $('file').textContent = state.filename + ' · ' + state.pages + ' pages';
    autoMarkCovers();
    wireQuick();
    $('btn').addEventListener('click', onRemove);
    updateCount();
    reveal();
    return;
  }
  // No usable PDF. Offer exactly one context-appropriate next step (never two).
  // file:// → the file-access helper was already shown by loadActivePdf.
  // JSTOR article page → offer the one-click opt-in (the only place it's useful).
  if (state.url.startsWith('file://')) return;
  if (isJstorUrl(state.url)) {
    let granted = false;
    try { granted = await chrome.permissions.contains({ origins: ['https://www.jstor.org/*'] }); } catch (_) { granted = true; }
    if (!granted) showJstorEnable();
  }
}
function selectPages(pages1) {
  state.remove = new Set(pages1.filter((n) => n >= 1 && n <= state.pages));
  $('grid').querySelectorAll('.thumb').forEach((t) => t.classList.toggle('mark', state.remove.has(+t.dataset.page)));
  updateCount();
}
// Pre-mark pages we're confident are covers (known site + text signatures).
// No banner — the ✕ marks on the grid are the whole message. The user sees
// exactly what will be removed and can adjust before downloading.
function autoMarkCovers() {
  const marks = PPR.detectCovers({ url: state.url, pageTexts: state.pageTexts });
  if (marks.length) selectPages(marks);
}
// Shown only on a JSTOR article page when the opt-in isn't granted — the one
// context where the on-page "Remove cover" button is relevant. Replaces the
// bare "not a PDF" status so the popup is useful there instead of a dead end.
function showJstorEnable() {
  $('status').classList.add('hidden');
  const row = $('jstorRow');
  row.classList.remove('hidden');
  const btn = $('jstorEnable');
  if (!btn.dataset.wired) {
    btn.dataset.wired = '1';
    btn.addEventListener('click', async () => {
      const granted = await chrome.permissions.request({ origins: ['https://www.jstor.org/*'] });
      if (granted) {
        row.innerHTML = '<div class="jr-txt"><b>Done.</b> Reload this JSTOR page — a “Remove cover” button will appear next to Download.</div>';
      }
    });
  }
}
document.addEventListener('DOMContentLoaded', boot);
