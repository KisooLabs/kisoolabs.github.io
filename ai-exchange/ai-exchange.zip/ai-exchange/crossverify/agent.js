// Runs inside chatgpt.com / gemini.google.com frames (isolated world).
// Reads the latest assistant answer and writes/sends into the input.
(function () {
  const core = globalThis.CrossVerifyCore;
  const sel = globalThis.CrossVerifySelectors;
  if (!core || !sel) return;
  const platform = core.pickPlatform(location.hostname, sel.PLATFORMS);
  if (!platform) return;
  const NS = 'cross-verify';

  // How long SEND waits for the thread to grow a new user turn before calling
  // the send failed. Gemini takes about a second to render one; the hub's SEND
  // deadline is 15s and the button poll takes up to 0.6s of that, so 6s leaves
  // room rather than racing it.
  const SENT_TIMEOUT = 6000;

  function latestResponse() {
    const nodes = document.querySelectorAll(platform.responseSelector);
    if (!nodes.length) return null;
    const last = nodes[nodes.length - 1];
    const inner = platform.responseTextSelector ? last.querySelector(platform.responseTextSelector) : null;
    const text = ((inner || last).innerText || '').trim();
    return text || null;
  }

  // Full-conversation read for the .md export. Walks every turn (user +
  // assistant) in document order. Role comes from a platform attribute
  // (ChatGPT) or a user-turn selector (Gemini); text prefers the answer text
  // node and falls back to the turn's own innerText (user turns have no
  // .markdown). Empty turns are dropped.
  function turnRole(el) {
    if (platform.turnRoleAttr) {
      return (el.getAttribute(platform.turnRoleAttr) || '').toLowerCase() === 'user' ? 'user' : 'assistant';
    }
    if (platform.userTurnSelector && el.matches && el.matches(platform.userTurnSelector)) return 'user';
    return 'assistant';
  }

  // A user turn may carry text the page shows only to a screen reader, and
  // reading the turn whole picks that up as if the user had typed it (Gemini's
  // <user-query> opens with a truncated "You said …" label). Where a platform
  // names the elements that hold the visible prompt, those are read instead,
  // joined on a newline because each is one line of it. No match falls through
  // to the whole turn, so a platform whose DOM changed degrades to the old
  // reading rather than to an empty turn.
  function turnText(el) {
    if (platform.userTextSelector && turnRole(el) === 'user') {
      const parts = el.querySelectorAll(platform.userTextSelector);
      if (parts.length) {
        const lines = [];
        for (let i = 0; i < parts.length; i++) lines.push((parts[i].innerText || '').trim());
        const joined = lines.join('\n').trim();
        if (joined) return joined;
      }
    }
    const inner = platform.responseTextSelector ? el.querySelector(platform.responseTextSelector) : null;
    return ((inner || el).innerText || '').trim();
  }

  function conversation() {
    const nodes = document.querySelectorAll(platform.turnSelector || platform.responseSelector);
    const turns = [];
    for (let i = 0; i < nodes.length; i++) {
      const text = turnText(nodes[i]);
      if (text) turns.push({ role: turnRole(nodes[i]), text: text });
    }
    return turns;
  }

  function inResponseBody(node) {
    return !!(platform.responseSelector && node.closest && node.closest(platform.responseSelector));
  }

  // Anchor to the chat composer: the last element matching `selector` that is
  // not inside a rendered answer. Keeps WRITE_AND_SEND off an editable/button
  // the model rendered inside its reply (e.g. an email-draft form) — which,
  // sitting above the composer in the DOM, a plain querySelector would hit
  // first. See core.lastOutsideResponse.
  function pickOutside(selector) {
    return core.lastOutsideResponse(
      Array.prototype.slice.call(document.querySelectorAll(selector)),
      inResponseBody
    );
  }

  // ---- Composer stamp: the app bundle's broadcast path reads this ---------
  // The header's broadcast composer does NOT use the RPC below. The app
  // bundle ships its own content script (assets/chunk-9af4a4ac.js) which
  // resolves the target with document.querySelector over
  // ["div[contenteditable]", "textarea"] — the FIRST match in document order —
  // because none of the four built-in apps carries an `inputSelector`. A
  // rendered answer sits ABOVE the composer, so any editable the model puts
  // inside its reply (an email-draft form; note the list matches
  // contenteditable="false" too) wins the query: the broadcast lands in the
  // answer, and the Enter that follows cannot submit from there either.
  //
  // Rather than teach the bundle a second copy of the targeting rules, we
  // publish OUR answer as an attribute and let its fallback list ask for the
  // stamp first. One targeting implementation (core.lastOutsideResponse), one
  // selector source (selectors.js), both write paths. When the stamp is absent
  // the bundle falls through to its own list — degraded to today's behaviour
  // for unsupported platforms, never worse.
  const STAMP = 'data-cv-input';

  // The element the last full resolve chose, so the steady state can skip the
  // resolve entirely. See stampStillValid.
  let stampedEl = null;
  let lastResolve = 0;
  const RESOLVE_FLOOR_MS = 250;

  // Is the remembered composer still the right target? All three checks walk
  // ancestors only (O(depth)), never the document, so a streaming answer's
  // mutation storm costs nothing. This is what keeps stampComposer affordable
  // on a long conversation: the O(document) resolve below then runs only when
  // the composer genuinely changed (navigation, new chat), not per token.
  function stampStillValid() {
    if (!stampedEl || !stampedEl.isConnected) return false;
    if (!stampedEl.matches || !stampedEl.matches(platform.inputSelector)) return false;
    return !inResponseBody(stampedEl);
  }

  function stampComposer() {
    if (stampStillValid()) return;
    // Floor between full resolves. Without it a page with no composer at all
    // (still loading, or a selector break) would run the document-wide query
    // on every mutation batch, which is the cost this whole path exists to
    // avoid. The composer cannot be swapped and then used by a human inside
    // one floor interval, so the stamp is still never stale at the moment the
    // bundle reads it.
    const now = Date.now();
    if (now - lastResolve < RESOLVE_FLOOR_MS) return;
    lastResolve = now;
    const el = pickOutside(platform.inputSelector);
    const stale = document.querySelectorAll('[' + STAMP + ']');
    for (let i = 0; i < stale.length; i++) {
      if (stale[i] !== el) stale[i].removeAttribute(STAMP);
    }
    if (el && !el.hasAttribute(STAMP)) el.setAttribute(STAMP, '1');
    stampedEl = el;
  }

  function setInput(text) {
    const el = pickOutside(platform.inputSelector);
    if (!el) return false;
    el.focus();
    if (platform.inputMethod === 'textarea') {
      const desc = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
      desc.set.call(el, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      const range = document.createRange();
      range.selectNodeContents(el);
      const s = window.getSelection();
      s.removeAllRanges();
      s.addRange(range);
      document.execCommand('insertText', false, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    }
    return true;
  }

  function clickSend() {
    const btn = pickOutside(platform.sendButtonSelector);
    if (btn) { btn.click(); return true; }
    const el = pickOutside(platform.inputSelector);
    if (el) {
      el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
      return true;
    }
    return false;
  }

  // The send button often mounts only a beat after the composer holds text
  // (measured ~50ms on Gemini). In the two-phase exchange FILL and SEND are
  // separate postMessage round-trips, so poll briefly for the button rather
  // than assume a fixed delay — otherwise SEND can race ahead of the button
  // and fall through to the (framework-ignored) Enter key.
  function waitForSendButton(timeout) {
    return new Promise(function (resolve) {
      const start = Date.now();
      (function poll() {
        if (pickOutside(platform.sendButtonSelector)) return resolve(true);
        if (Date.now() - start >= timeout) return resolve(false);
        setTimeout(poll, 50);
      })();
    });
  }

  // An empty composer is necessary for a send but NOT sufficient, so this is a
  // fallback signal rather than the answer. Measured 2026-08-28: a panel whose
  // session has gone stale inside the frame clears the composer and drops the
  // message, and a panel in the other stale mode ignores the click entirely and
  // keeps the text. Only the first of those two used to be reported honestly.
  function composerIsEmpty() {
    const el = pickOutside(platform.inputSelector);
    if (!el) return false;
    const text = platform.inputMethod === 'textarea' ? (el.value || '') : (el.innerText || '');
    return text.trim() === '';
  }

  // The thread's last user turn, or null when there is none yet. `undefined`
  // means this platform exposes no user-turn signal at all.
  //
  // Identity is the signal, not a count and not the text. A count is wrong the
  // moment the user carries one panel's conversation further on their own,
  // which is a thing the product is meant to allow; the text is wrong when the
  // same exchange prompt is sent twice in a row, since both turns read the
  // same. A send that actually happened always appends a NEW node.
  function lastUserTurn() {
    let nodes;
    if (platform.turnRoleAttr) {
      nodes = document.querySelectorAll('[' + platform.turnRoleAttr + '="user"]');
    } else if (platform.userTurnSelector) {
      nodes = document.querySelectorAll(platform.userTurnSelector);
    } else {
      return undefined;
    }
    return nodes.length ? nodes[nodes.length - 1] : null;
  }

  // Confirm the send by watching for that new user turn. Falls back to the
  // composer check only where there is no user-turn signal to watch, which is
  // the old behavior kept for a platform the table does not describe fully.
  // A framework that reuses the turn node would make this report a failure for
  // a send that worked; that direction is the safe one, since the alternative
  // is telling the user a message went when it did not.
  function waitForSent(before, timeout) {
    return new Promise(function (resolve) {
      if (before === undefined) {
        setTimeout(function () { resolve(composerIsEmpty()); }, 500);
        return;
      }
      const start = Date.now();
      (function poll() {
        const now = lastUserTurn();
        if (now && now !== before) return resolve(true);
        if (Date.now() - start >= timeout) return resolve(false);
        setTimeout(poll, 100);
      })();
    });
  }

  window.addEventListener('message', function (ev) {
    const msg = ev.data;
    if (!msg || msg.source !== NS || msg.type !== 'request') return;
    function reply(data, error) {
      ev.source.postMessage({ source: NS, type: 'response', id: msg.id, data: data, error: error }, '*');
    }
    try {
      if (msg.action === 'READ_RESPONSE') {
        const text = latestResponse();
        if (!text) return reply(null, 'NO_RESPONSE');
        return reply({ text: text, platformId: platform.id });
      }
      if (msg.action === 'READ_CONVERSATION') {
        const turns = conversation();
        if (!turns.length) return reply(null, 'NO_RESPONSE');
        return reply({ turns: turns, platformId: platform.id });
      }
      // Two-phase exchange (all-or-nothing): the hub FILLs every panel, and only
      // if every fill succeeds does it SEND — so one panel's failure can never
      // leave the others sent. FILL never submits.
      if (msg.action === 'FILL') {
        if (!setInput(msg.data.text)) return reply(null, 'NO_INPUT');
        return reply({ ok: true });
      }
      if (msg.action === 'SEND') {
        // Read the baseline before the click, and before the button wait, so a
        // turn appended by the send itself can never be mistaken for one that
        // was already there.
        const beforeTurn = lastUserTurn();
        waitForSendButton(600).then(function () {
          if (!clickSend()) return reply(null, 'NO_SEND');
          // Report whether the thread actually grew a turn, rather than merely
          // that a click happened or that the composer went empty.
          waitForSent(beforeTurn, SENT_TIMEOUT).then(function (sent) {
            reply({ ok: true, sent: sent });
          });
        });
        return;
      }
    } catch (e) {
      reply(null, String((e && e.message) || e));
    }
  });

  // Report this frame's document.title up to the hub so the browser tab can
  // show the leftmost panel's conversation title. The hub can't read a
  // cross-origin iframe's title, so each panel pushes its own. Only from a
  // framed page (a panel), never a normal top-level LLM tab. LLM SPAs rewrite
  // <title> on navigation (often replacing the node), so a light poll is more
  // reliable here than observing a single title node.
  // Keep the stamp on the live composer. Only panels need it (the app bundle's
  // content script activates only when the frame's ancestor is the extension),
  // so a normal chatgpt.com tab pays nothing. Every mutation batch still calls
  // stampComposer — there is no debounce, so the stamp can never be stale at
  // the moment the bundle reads it — but the call is now O(depth) in the steady
  // state (stampStillValid), not a document-wide querySelectorAll. The original
  // version did the full query on every batch, which on a long conversation
  // meant walking a huge DOM tens of times a second while an answer streamed;
  // that starved the frame's main thread and was the panel slowdown (and the
  // source of Exchange's RPC timeouts, since a busy frame cannot answer the
  // hub's postMessage in time). `attributes` is deliberately NOT observed:
  // our own setAttribute would otherwise re-enter the observer forever (the
  // enforceLight freeze, hub.js).
  if (window.top !== window.self) {
    stampComposer();
    new MutationObserver(function () {
      try { stampComposer(); } catch (e) {}
    }).observe(document.documentElement, { childList: true, subtree: true });
  }

  if (window.top !== window.self) {
    let lastTitle = null;
    function reportTitle() {
      if (document.title === lastTitle) return;
      lastTitle = document.title;
      try { window.parent.postMessage({ source: NS, type: 'title', title: document.title }, '*'); } catch (e) {}
    }
    reportTitle();
    setInterval(reportTitle, 1500);
  }
})();
