// Small shared UI pieces: the icon set and the toast. Kept apart from the
// feature modules so an icon is defined once and every button that uses it
// renders at the same size.
(function (root, factory) {
  const api = factory();
  root.AixUi = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  // Stroke-only paths on a 24x24 box, coloured by `currentColor`, so one
  // definition works on a light button, a dark button, and a disabled one.
  const ICONS = {
    exchange: '<path d="M4 8h13M14 4.5 17.5 8 14 11.5"/><path d="M20 16H7M10 12.5 6.5 16l3.5 3.5"/>',
    download: '<path d="M12 4v11M8 11.5 12 15.5 16 11.5M5 19h14"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><ellipse cx="12" cy="12" rx="4.2" ry="9"/>',
    gear: '<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33 1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82 1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M4 20h4l10-10a2.5 2.5 0 0 0-3.5-3.5L4.5 16.5z"/>',
    send: '<path d="M5 12h13M12.5 6.5 18.5 12l-6 5.5"/>',
    reload: '<path d="M20 12a8 8 0 1 1-2.5-5.8"/><path d="M20 4v4.5h-4.5"/>',
    fullscreen: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    external: '<path d="M14 4h6v6"/><path d="M20 4 11 13"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
    close: '<path d="M6 6 18 18M18 6 6 18"/>'
  };

  // The brand mark: a filled square carrying the same exchange arrows the
  // Exchange button uses, so the logo and the feature read as one thing. Filled
  // rather than stroked, because at 28px a stroke-only mark disappears next to
  // the outlined buttons around it.
  //
  // The two stops are CSS custom properties rather than literals, so the mark's
  // colour is set in the palette with everything else. Inline SVG in the
  // document resolves them like any other element.
  //
  // The arrows are the 24-box `exchange` paths above, mapped into the square at
  // about 62% of its width: scale 0.723 puts 24 units at 17.4px, and the 5.3
  // offset centres that inside 28.
  function brandMark(size) {
    const px = size || 28;
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 28 28');
    svg.setAttribute('width', String(px));
    svg.setAttribute('height', String(px));
    svg.setAttribute('aria-hidden', 'true');
    svg.classList.add('aix-mark');
    svg.innerHTML =
      '<defs><linearGradient id="aix-mark-g" x1="0" y1="0" x2="1" y2="1">'
      + '<stop offset="0" stop-color="var(--aix-mark-from)"/>'
      + '<stop offset="1" stop-color="var(--aix-mark-to)"/>'
      + '</linearGradient></defs>'
      + '<rect x="0" y="0" width="28" height="28" rx="8" fill="url(#aix-mark-g)"/>'
      + '<g transform="translate(5.3,5.3) scale(0.723)" fill="none" stroke="#fff"'
      + ' stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round">'
      + ICONS.exchange
      + '</g>';
    return svg;
  }

  function icon(name, strokeWidth) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', String(strokeWidth || 1.8));
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');
    svg.setAttribute('aria-hidden', 'true');
    svg.innerHTML = ICONS[name] || '';
    return svg;
  }

  // An icon-only control still needs an accessible name, so `label` becomes both
  // the tooltip and the aria-label rather than being dropped.
  function iconButton(name, label, onClick, className) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'aix-icon-btn' + (className ? ' ' + className : '');
    b.title = label;
    b.setAttribute('aria-label', label);
    b.appendChild(icon(name));
    if (onClick) b.addEventListener('click', onClick);
    return b;
  }

  function textButton(name, label, onClick, className) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'aix-btn' + (className ? ' ' + className : '');
    if (name) b.appendChild(icon(name));
    b.appendChild(document.createTextNode(label));
    if (onClick) b.addEventListener('click', onClick);
    return b;
  }

  let toastTimer = null;
  function toast(message) {
    let el = document.getElementById('aix-toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'aix-toast';
      el.className = 'aix-toast';
      el.setAttribute('role', 'status');
      document.body.appendChild(el);
    }
    el.textContent = message;
    el.classList.add('aix-show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('aix-show'); }, 2600);
  }

  return { ICONS, icon, brandMark, iconButton, textButton, toast };
});
