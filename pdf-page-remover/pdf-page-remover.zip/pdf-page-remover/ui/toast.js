// src/ui/toast.js — status toasts (extracted from v1 content.js).
(function (root) {
  'use strict';

  const UI_FONT = '-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif';

  // ---------------------------------------------------------------- styles ---
  function injectStyles() {
    if (document.getElementById('ppr-toast-style')) return;
    const s = document.createElement('style');
    s.id = 'ppr-toast-style';
    s.textContent = `
      .jstor-nocover-btn[data-nc-variant="primary"]:hover { filter: brightness(1.06); box-shadow: 0 3px 10px rgba(0,0,0,.22); }
      .jstor-nocover-btn[data-nc-variant="secondary"]:hover { background: rgba(0,0,0,.05) !important; }
      .jstor-nocover-btn:active { transform: translateY(1px); }
      .jstor-nocover-btn[disabled] { opacity: .6; cursor: default; pointer-events: none; }
      #ppr-toasts {
        position: fixed; top: 74px; right: 22px; z-index: 2147483647;
        display: flex; flex-direction: column; gap: 12px; width: 420px;
        font-family: ${UI_FONT}; pointer-events: none;
      }
      .jnc-toast {
        pointer-events: auto; width: 100%; color: #1a1a1a; background: #fff;
        border-radius: 18px;
        box-shadow: 0 0 0 1px rgba(20,20,20,.06), 0 18px 40px rgba(0,0,0,.16);
        display: flex; flex-direction: column; align-items: stretch;
        animation: jncslide .2s ease;
      }
      .jnc-head {
        display: flex; align-items: center; gap: 10px; padding: 14px 18px;
        background: #eaf1fb; color: #10457f; font-weight: 700; font-size: 17px; line-height: 1.35;
        border-radius: 18px 18px 0 0;
      }
      .jnc-head:last-child { border-radius: 18px; }
      .jnc-close {
        margin-left: auto; flex: none; border: 0; background: transparent; color: inherit;
        font-size: 15px; line-height: 1; cursor: pointer; opacity: .5; padding: 3px 5px;
        border-radius: 7px; font-family: inherit;
      }
      .jnc-close:hover { opacity: 1; background: rgba(0,0,0,.09); }
      .jnc-toast.ok  .jnc-head { background: #e7f6ec; color: #1c7a32; }
      .jnc-toast.err .jnc-head { background: #fdeceb; color: #b3271c; }
      .jnc-body { padding: 13px 18px 16px; font-size: 16px; line-height: 1.5;
                  background: #fff; border-radius: 0 0 18px 18px; }
      .jnc-body small { display: block; color: #555; font-size: 14.5px; margin-top: 5px; }
      .jnc-body small:first-child { margin-top: 0; }
      .jnc-mono { font-family: ui-monospace, Consolas, monospace; font-size: 13.5px; word-break: break-all; }
      .jnc-sp {
        width: 19px; height: 19px; border: 3px solid #bcd2ef; border-top-color: #1a5fb4;
        border-radius: 50%; animation: jncspin .7s linear infinite; flex: none;
      }
      .jnc-badge { font-size: 19px; line-height: 1; flex: none; }
      @keyframes jncspin { to { transform: rotate(360deg); } }
      @keyframes jncslide { from { opacity: 0; transform: translateX(24px); } to { opacity: 1; transform: none; } }
    `;
    (document.head || document.documentElement).appendChild(s);
  }

  // ---------------------------------------------------------------- toasts ---
  function toastHost() {
    let h = document.getElementById('ppr-toasts');
    if (!h) {
      h = document.createElement('div');
      h.id = 'ppr-toasts';
      (document.body || document.documentElement).appendChild(h);
    }
    return h;
  }
  // A toast is a coloured header band (state at a glance) + an optional body.
  //   o = { state:'' | 'ok' | 'err', title, body, spinner, badge }
  function renderToast(el, o) {
    el.className = 'jnc-toast' + (o.state ? ' ' + o.state : '');
    const icon = o.spinner
      ? '<span class="jnc-sp"></span>'
      : (o.badge ? '<span class="jnc-badge">' + o.badge + '</span>' : '');
    el.innerHTML =
      '<div class="jnc-head">' + icon + '<span>' + o.title + '</span>' +
      '<button class="jnc-close" type="button" aria-label="Close" title="Close">✕</button></div>' +
      (o.body ? '<div class="jnc-body">' + o.body + '</div>' : '');
    // Re-attached on every render (setToast rebuilds innerHTML on state changes).
    const close = el.querySelector('.jnc-close');
    if (close) close.addEventListener('click', () => el.remove());
  }
  function toast(o) {
    injectStyles();
    const el = document.createElement('div');
    renderToast(el, o);
    toastHost().appendChild(el);
    if (o.state) setTimeout(() => el.remove(), o.state === 'err' ? 7000 : 5000);
    return el;
  }
  function setToast(el, o) { renderToast(el, o); }
  function toastErr(title, sub = '') {
    toast({ state: 'err', badge: '⚠️', title: esc(title), body: sub ? '<small>' + esc(sub) + '</small>' : '' });
  }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  const api = { toast, setToast, toastErr, esc };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.PPR = root.PPR || {}; Object.assign(root.PPR, api); }
})(typeof self !== 'undefined' ? self : globalThis);
