// Keeps keyboard focus in the composer when a panel takes it uninvited.
//
// A panel is a cross-origin iframe, and a frame that calls focus() on one of
// its own elements pulls keyboard focus out of this page. ChatGPT does it when
// its composer mounts, once more after chatgpt-sidebar.js reloads the frame,
// and any panel may do it again after a reload or when it is first added. The
// hub cannot see a click inside a frame, so from here a steal and a click look
// the same: the window fires `blur` and document.activeElement becomes the
// iframe.
//
// Two signals tell them apart. The panel's agent reports every focus that
// lands inside it together with whether a pointer or key went down in that
// frame just before, which a click has and a mount-time focus() does not. And
// when no report comes (the frame's agent is not injected yet, or the frame
// itself was focused with no element, which Gemini's first paint does),
// navigator.userActivation.hasBeenActive decides: it is false only while
// nobody has interacted with this page or any panel (a frame's activation
// propagates to its ancestors; measured false at the start of the hub page
// whether opened by Page.navigate or by chrome.tabs.create, with or without a
// gesture on the caller, 2026-09-17), and a focus move with no interaction
// anywhere is never the user's. After the first interaction a report-less
// focus move is left alone, which is the residual: a panel that focuses only
// its frame, never an element, keeps the focus after a reload.
//
// The guard acts only when focus leaves THIS document for a panel. A panel
// focusing itself while the user works in another panel never blurs the hub
// window, so it is never touched, and the one keyboard route into a panel (Tab
// from the last control before it) is let through by the Tab grace.
(function (root, factory) {
  const api = factory();
  root.AixFocus = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  // How long to wait for the panel's own report before deciding from the
  // page-level signal alone. The frame posts its report in the same task as
  // the focus change, but a cross-process postMessage is queued as a task in
  // the SENDING frame, so it leaves only when that frame's current task ends:
  // measured 2026-09-17, ChatGPT's report arrived 350ms after its mount-time
  // focus (265ms after a reload) while Claude's took 13ms. The wait costs
  // nothing on a click, whose report ends it as soon as it arrives.
  const REPORT_WAIT_MS = 1500;
  // A report that arrived just before the blur settled is still about it.
  const REPORT_FRESH_MS = 300;
  // A Tab pressed here this recently means the user is walking into the panel.
  const TAB_GRACE_MS = 500;

  // deps: activeElement(), isPanelFrame(el), hasBeenActive(), focusComposer(),
  // and optionally now / setTimeout / clearTimeout for tests.
  function create(deps) {
    const now = deps.now || Date.now;
    const later = deps.setTimeout || setTimeout;
    const cancel = deps.clearTimeout || clearTimeout;
    const reports = new WeakMap(); // frame -> { user, at }
    let lastTabAt = -Infinity;
    let pending = null;

    function activePanelFrame() {
      const el = deps.activeElement();
      return el && deps.isPanelFrame(el) ? el : null;
    }

    // user: true = the user put focus there, false = the frame took it,
    // null = no report came, decide from the page-level signal.
    function settle(user) {
      if (pending !== null) { cancel(pending); pending = null; }
      if (user === true) return;
      if (user === false || !deps.hasBeenActive()) deps.focusComposer();
    }

    // window 'blur': focus left this document. Where it went is only known
    // once the browser has finished moving it, hence the deferral.
    function windowBlurred() {
      later(function () {
        const frame = activePanelFrame();
        if (!frame) return; // another window, another tab, or nothing at all
        if (now() - lastTabAt < TAB_GRACE_MS) return;
        const r = reports.get(frame);
        if (r && now() - r.at < REPORT_FRESH_MS) { settle(r.user); return; }
        if (pending !== null) cancel(pending);
        pending = later(function () {
          pending = null;
          if (activePanelFrame()) settle(null);
        }, REPORT_WAIT_MS);
      }, 0);
    }

    function frameReported(frame, user) {
      reports.set(frame, { user: user, at: now() });
      if (pending !== null && activePanelFrame() === frame) settle(user);
    }

    function keydown(key) {
      if (key === 'Tab') lastTabAt = now();
    }

    return { windowBlurred, frameReported, keydown };
  }

  return { create, REPORT_WAIT_MS, REPORT_FRESH_MS, TAB_GRACE_MS };
});
