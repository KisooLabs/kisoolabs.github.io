(function (root) {
  const ILLEGAL = /[\\/:*?"<>|]/g;   // Windows-illegal + path separators
  function sanitizeFilename(name) {
    let n = String(name).replace(/[\r\n\t]/g, '').replace(ILLEGAL, '_').trim();
    if (!n) n = 'document';
    if (!/\.pdf$/i.test(n)) n += '.pdf';
    return n;
  }
  function parseFilename(cd, fallbackId) {
    let name = null;
    if (cd) {
      let m = cd.match(/filename\*=(?:UTF-8'')?([^;]+)/i);
      if (m) {
        const raw = m[1].trim().replace(/^"|"$/g, '');
        try { name = decodeURIComponent(raw); } catch (_) { name = raw; }
      }
      if (!name) { m = cd.match(/filename=("?)([^";]+)\1/i); if (m) name = m[2].trim(); }
    }
    if (!name) name = String(fallbackId);
    return sanitizeFilename(name);
  }
  const api = { parseFilename, sanitizeFilename };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.PPR = root.PPR || {}; Object.assign(root.PPR, api); }
})(typeof self !== 'undefined' ? self : globalThis);
