// The panel grid: the only code that creates, destroys, or measures panel
// iframes. Every feature (Exchange, broadcast, export, title sync) asks this
// module for panels instead of running its own querySelectorAll('iframe').
//
// Two rules hold the whole design together, and both exist because a panel is a
// cross-origin iframe whose document is expensive and irreplaceable (a logged-in
// session, a scroll position, a half-typed prompt, an answer still streaming):
//
//   1. Panel DOM is append-and-remove only. A column element is never moved in
//      the document, because moving an iframe element makes the browser reload
//      its document. Visual order comes from the CSS `order` property, written
//      from the state module's panel array.
//   2. The id-to-element map holds references. Nothing re-queries the DOM to
//      find a panel, so element identity is stable for as long as the panel is
//      open, which is what lets a postMessage reply be matched to its sender by
//      `event.source === iframe.contentWindow`.
(function (root, factory) {
  const api = factory();
  root.AixPanels = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  // id -> { id, platform, col, frame }
  const open = new Map();
  let gridEl = null;

  function mount(el) {
    gridEl = el;
    return api;
  }

  function get(id) {
    return open.get(id) || null;
  }

  function has(id) {
    return open.has(id);
  }

  // Panels in the order the caller's id array specifies, skipping any that are
  // not open. Callers pass state.panels, so "order" always comes from the model.
  function inOrder(ids) {
    const out = [];
    for (let i = 0; i < ids.length; i++) {
      const p = open.get(ids[i]);
      if (p) out.push(p);
    }
    return out;
  }

  function count() {
    return open.size;
  }

  // Find the panel that sent a postMessage, by window identity. Returns null for
  // any window that is not one of ours, which is what keeps a stray frame from
  // being mistaken for a panel.
  function bySource(win) {
    for (const p of open.values()) {
      if (p.frame.contentWindow === win) return p;
    }
    return null;
  }

  function create(platform) {
    if (!gridEl) throw new Error('panels.mount() has not run');
    const existing = open.get(platform.id);
    if (existing) return existing;

    const col = document.createElement('div');
    col.className = 'aix-col';
    col.dataset.panel = platform.id;

    const bar = document.createElement('div');
    bar.className = 'aix-col-bar';
    const title = document.createElement('span');
    title.className = 'aix-col-title';
    title.textContent = platform.id;
    bar.appendChild(title);
    const tools = document.createElement('div');
    tools.className = 'aix-col-tools';
    bar.appendChild(tools);

    const wrap = document.createElement('div');
    wrap.className = 'aix-col-frame';
    const frame = document.createElement('iframe');
    frame.src = platform.url;
    frame.setAttribute('allow', 'clipboard-read; clipboard-write');
    wrap.appendChild(frame);

    col.appendChild(bar);
    col.appendChild(wrap);
    gridEl.appendChild(col);

    const panel = { id: platform.id, platform: platform, col: col, frame: frame, bar: bar, tools: tools, title: title };
    open.set(platform.id, panel);
    return panel;
  }

  function destroy(id) {
    const p = open.get(id);
    if (!p) return false;
    p.col.remove();
    open.delete(id);
    return true;
  }

  // Reload a panel without touching its element: assigning src re-navigates the
  // existing frame, which is the one document-replacing operation that is
  // intended here.
  function reload(id) {
    const p = open.get(id);
    if (!p) return false;
    p.frame.src = p.frame.src;
    return true;
  }

  // Render the model's order onto the view. Called after every state change; it
  // only writes CSS `order`, so no element moves and no document reloads.
  function applyOrder(ids) {
    for (let i = 0; i < ids.length; i++) {
      const p = open.get(ids[i]);
      if (p) p.col.style.order = String(i + 1);
    }
  }

  // Show one panel alone, or all of them again with fullscreen(null).
  function fullscreen(id) {
    for (const p of open.values()) {
      p.col.classList.toggle('aix-hidden', !!id && p.id !== id);
      p.col.classList.toggle('aix-full', !!id && p.id === id);
    }
  }

  // Bring the open set into agreement with the model, creating and destroying
  // only what changed, then re-render order. Panels that stay open keep their
  // element, their document, and their conversation.
  function sync(ids, platformById) {
    const wanted = Object.create(null);
    for (let i = 0; i < ids.length; i++) wanted[ids[i]] = true;
    for (const id of Array.from(open.keys())) {
      if (!wanted[id]) destroy(id);
    }
    for (let i = 0; i < ids.length; i++) {
      const plat = platformById[ids[i]];
      if (plat) create(plat);
    }
    applyOrder(ids);
  }

  const api = { mount, create, destroy, reload, applyOrder, fullscreen, sync, get, has, inOrder, count, bySource };
  return api;
});
