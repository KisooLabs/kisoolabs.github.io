// Runs inside embedded chatgpt.com frames only.
//
// Why this exists: ChatGPT stores its sidebar open/collapsed state in the
// `oai-nav-state` cookie, which is SameSite=Lax and therefore never reaches a
// cross-site iframe. With that cookie absent, ChatGPT renders the sidebar in two
// contradictory halves (live-diagnosed 2026-08-21, CDP-attached real Chrome):
//   · the container #stage-slideover-sidebar gets the EXPANDED inline width
//     (style="width: var(--sidebar-width)" = 260px), while
//   · the content pane inside it gets the COLLAPSED render
//     (class "pointer-events-none opacity-0").
// The chat history is fully present in the DOM (28 a[href^="/c/"] links in the
// repro) but paints nothing, so the panel shows a 260px sidebar of which only the
// 52px icon rail is visible and the remaining ~208px is a blank strip.
//
// TWO FACTS THAT DECIDE THE DESIGN (both measured, 2026-08-21/22):
//   (a) A frame whose document loads with oai-nav-state=0, or with the cookie
//       absent, comes up DEAD: the rail's "open sidebar" button does nothing, for
//       a synthetic click and for a real trusted mouse click alike. Only a
//       document that loaded EXPANDED has a working toggle.
//   (b) A document that loaded expanded toggles perfectly in both directions,
//       but ChatGPT cannot persist the change (its own cookie write is Lax and is
//       rejected in the frame), so the choice is forgotten on the next load.
// So the cookie cannot carry the user's choice: remembering "collapsed" through
// oai-nav-state would load a frame the user cannot re-expand. Instead the frame
// ALWAYS loads expanded, the choice is remembered in our own cookie, and a
// collapsed choice is replayed by clicking ChatGPT's own collapse control once
// the sidebar mounts, which leaves React in the state it would have reached had
// the user clicked it.
//
// Four parts, in the order they run:
//   1. WIDTH GUARD (css) — pin the container to the rail width whenever the pane
//      is in the collapsed render, which is exactly when a 260px container would
//      paint blank. Also hide the sidebar while a remembered collapse is still
//      pending, so the expanded state never flashes.
//   2. SEED — force oai-nav-state=1 (the only value that boots a working frame)
//      and reload once when it was absent or wrong.
//   3. REPLAY — if the remembered choice is "closed", click the collapse control
//      once the sidebar mounts.
//   4. REMEMBER — mirror the rendered state into our own cookie so the next load
//      replays it.
(function () {
  // Top-level chatgpt.com (a normal tab) has its own oai-nav-state: do nothing.
  if (window.top === window.self) return;
  if (!/(^|\.)chatgpt\.com$/.test(location.hostname)) return;

  var OAI_COOKIE = 'oai-nav-state';
  var OAI_WORKING = '1'; // the only value that boots a frame with a live toggle (fact (a))
  var MEMO = 'cv-sidebar-state'; // ours: 'open' | 'closed'
  var GUARD = 'cv-chatgpt-navstate-reloaded';
  var STYLE_ID = 'cv-chatgpt-sidebar-style';
  var PENDING = 'data-cv-sidebar-collapsing';
  var ATTRS = '; path=/; Max-Age=31536000; SameSite=None; Secure';
  var SIDEBAR = '#stage-slideover-sidebar';
  var PANE = SIDEBAR + ' > div > div'; // the tiny bar is a <nav>, so this is the content pane
  var COLLAPSE_BTN = SIDEBAR + ' [data-testid="close-sidebar-button"]';
  var COLLAPSED_CLASS = 'opacity-0';
  var MAX_REPLAY_TRIES = 60; // ~ the mount-to-hydration window; then give up expanded

  // ---- cookie helpers -------------------------------------------------------
  function read(name) {
    try {
      var m = document.cookie.match(new RegExp('(^|;\\s*)' + name + '=([^;]*)'));
      return m ? m[2] : null;
    } catch (e) { return null; }
  }

  function write(name, value) {
    try { document.cookie = name + '=' + value + ATTRS; } catch (e) { /* fall through */ }
    // Chrome rejects SameSite=None without Partitioned once third-party cookies
    // are blocked; retry in the partitioned form before giving up.
    if (read(name) !== value) {
      try { document.cookie = name + '=' + value + ATTRS + '; Partitioned'; } catch (e) { /* fall through */ }
    }
    return read(name) === value;
  }

  var wantsCollapsed = read(MEMO) === 'closed';

  // ---- 1. width guard -------------------------------------------------------
  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    var style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = ''
      // The desynced render: contents collapsed, container still at 260px.
      + SIDEBAR + ':has(> div > div.pointer-events-none.' + COLLAPSED_CLASS + ')'
      + '{width:var(--sidebar-rail-width) !important;}'
      // A remembered collapse is replayed a moment after mount; keep the sidebar
      // at rail width and its pane invisible until then so it never flashes open.
      + 'html[' + PENDING + '] ' + SIDEBAR
      + '{width:var(--sidebar-rail-width) !important;}'
      + 'html[' + PENDING + '] ' + PANE
      + '{opacity:0 !important;pointer-events:none !important;}';
    (document.head || document.documentElement).appendChild(style);
  }
  ensureStyle();
  if (wantsCollapsed) document.documentElement.setAttribute(PENDING, '');

  // ---- 2. seed --------------------------------------------------------------
  if (read(OAI_COOKIE) !== OAI_WORKING) {
    // Write blocked outright: leave the frame as it was rather than reload.
    if (!write(OAI_COOKIE, OAI_WORKING)) {
      document.documentElement.removeAttribute(PENDING);
      return;
    }
    // The document was already requested with the wrong value, so the dead-toggle
    // render is baked into THIS document — only a reload fixes it. sessionStorage
    // gates the reload to once per frame session: if the cookie somehow fails to
    // stick, the frame must degrade to the old blank strip, never into a reload
    // loop.
    var mayReload = false;
    try {
      if (!sessionStorage.getItem(GUARD)) {
        sessionStorage.setItem(GUARD, '1');
        mayReload = true;
      }
    } catch (e) { mayReload = false; } // no sessionStorage means no loop guard: do not reload
    if (mayReload) { location.reload(); return; }
  }

  // ---- 3. replay + 4. remember ---------------------------------------------
  function isCollapsed(pane) { return pane.classList.contains(COLLAPSED_CLASS); }

  var replayTries = 0;

  function endReplay() {
    wantsCollapsed = false;
    document.documentElement.removeAttribute(PENDING);
  }

  // The collapse control is inert until React hydrates, and a click that lands
  // too early produces no mutation to react to, so the replay is driven by its
  // own timer rather than by the observer.
  function replayPump() {
    if (!wantsCollapsed) return;
    var pane = document.querySelector(PANE);
    if (pane && isCollapsed(pane)) { endReplay(); return; }
    if (replayTries >= MAX_REPLAY_TRIES) {
      // Could not replay: show the working expanded sidebar rather than a masked
      // one the user cannot open.
      endReplay();
      return;
    }
    replayTries++;
    var btn = document.querySelector(COLLAPSE_BTN);
    if (btn) btn.click();
    setTimeout(replayPump, 100);
  }
  if (wantsCollapsed) setTimeout(replayPump, 0);

  function settle(pane) {
    if (wantsCollapsed) {
      if (!isCollapsed(pane)) return; // the replay owns the state until it lands
      endReplay();
    }
    var now = isCollapsed(pane) ? 'closed' : 'open';
    if (read(MEMO) !== now) write(MEMO, now); // only write when the state changed
  }

  var watched = null;
  var paneObserver = new MutationObserver(function () {
    if (watched) settle(watched);
  });

  function attach() {
    if (watched && watched.isConnected) return;
    var pane = document.querySelector(PANE);
    if (!pane) return;
    paneObserver.disconnect();
    watched = pane;
    // One attribute on one element: streaming answers live outside the sidebar
    // and cannot reach this observer.
    paneObserver.observe(pane, { attributes: true, attributeFilter: ['class'] });
    settle(pane);
  }

  attach();
  // The sidebar mounts after document_start and React can remount it on SPA
  // navigation, so keep a finder alive. Its callback exits on an `isConnected`
  // read whenever the pane is already watched.
  new MutationObserver(attach).observe(document.documentElement, { childList: true, subtree: true });
})();
