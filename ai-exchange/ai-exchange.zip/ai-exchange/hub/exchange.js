// Exchange: read every panel's latest answer, then give each panel the OTHER
// panels' answers wrapped in the verification prompt, and submit.
//
// The orchestration is carried over from the injection layer with its semantics
// intact. What changed is where the pieces come from: panels arrive from the
// panel API in the model's order instead of being discovered by scanning the
// document and sorting by measured x-coordinate, and the two-phase fill-then-send
// now lives in rpc.js, shared with broadcast.
(function (root, factory) {
  const api = factory();
  root.AixExchange = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  let busy = false;

  function isBusy() {
    return busy;
  }

  // ctx: { panels, msg, settings, rpc, core, ui, onBusy }
  function run(ctx) {
    if (busy) return Promise.resolve({ skipped: 'busy' });
    const panels = ctx.panels;
    const msg = ctx.msg;
    const core = ctx.core;

    if (panels.length < 2) {
      ctx.ui.toast(msg.gateNeed2);
      return Promise.resolve({ skipped: 'gate' });
    }

    busy = true;
    ctx.onBusy(true);

    const failLabels = {
      NO_RESPONSE: msg.failNoResponse, TIMEOUT: msg.failTimeout,
      NO_INPUT: msg.failNoInput, NO_SEND: msg.failNoSend
    };

    return ctx.rpc.each(panels, 'READ_RESPONSE', {})
      .then(function (reads) {
        const failed = reads.filter(function (r) { return !r.ok; });
        if (failed.length) {
          ctx.ui.toast(msg.readFail + core.describePanelFailures(
            failed.map(function (r) { return { name: r.id, error: r.error }; }), failLabels));
          return { phase: 'read', failures: failed };
        }
        const textById = Object.create(null);
        reads.forEach(function (r) { textById[r.id] = r.data.text; });

        // Each panel receives every OTHER panel's answer, its own excluded, each
        // headed by the model name so a three-way or four-way exchange stays
        // attributable. With two panels the single other answer goes in raw.
        function textFor(panel) {
          const others = [];
          panels.forEach(function (p) {
            if (p.id === panel.id) return;
            others.push({ name: p.id, text: textById[p.id] });
          });
          return core.wrapAnswer(ctx.settings.template, others);
        }

        return ctx.rpc.fillThenSend(panels, textFor, { autoSend: ctx.settings.autoSend })
          .then(function (out) {
            if (out.phase === 'fill') {
              ctx.ui.toast(msg.fillFail + core.describePanelFailures(
                out.failures.map(function (r) { return { name: r.id, error: r.error }; }), failLabels));
            } else if (out.phase === 'send') {
              ctx.ui.toast(msg.sendFail + core.describePanelFailures(
                out.failures.map(function (r) { return { name: r.id, error: r.error }; }), failLabels));
            } else if (out.phase === 'filled') {
              ctx.ui.toast(msg.filled);
            } else if (out.notSent && out.notSent.length) {
              ctx.ui.toast(globalThis.CrossVerifyI18N.format(msg.partial, {
                panels: out.notSent.map(function (r) { return r.id; }).join(', ')
              }));
            } else {
              ctx.ui.toast(msg.allDone);
            }
            return out;
          });
      })
      .catch(function (e) {
        ctx.ui.toast(msg.fail + e.message);
        return { phase: 'error', error: e.message };
      })
      .then(function (out) {
        busy = false;
        ctx.onBusy(false);
        return out;
      });
  }

  // Settings popover: the exchange prompt template and the auto-send toggle.
  // The gear is its only trigger; the Exchange segment never opens it.
  function openSettings(anchor, ctx) {
    closeSettings();
    const msg = ctx.msg;
    const pop = document.createElement('div');
    pop.id = 'aix-pop';
    pop.className = 'aix-pop';

    const title = document.createElement('div');
    title.className = 'aix-pop-title';
    title.textContent = msg.popTitle;

    const label = document.createElement('label');
    label.className = 'aix-pop-label';
    label.textContent = msg.popTemplate;

    const ta = document.createElement('textarea');
    ta.className = 'aix-pop-tpl';
    ta.value = ctx.settings.template;

    const hint = document.createElement('div');
    hint.className = 'aix-pop-hint';
    hint.textContent = msg.popHint;

    const auto = document.createElement('label');
    auto.className = 'aix-pop-switch';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = !!ctx.settings.autoSend;
    auto.appendChild(cb);
    auto.appendChild(document.createTextNode(' ' + msg.popAutoSend));

    const row = document.createElement('div');
    row.className = 'aix-pop-row';
    const reset = document.createElement('button');
    reset.type = 'button';
    reset.className = 'aix-btn aix-pop-ghost';
    reset.textContent = msg.popReset;
    reset.addEventListener('click', function () { ta.value = ctx.defaultTemplate; });
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'aix-btn aix-pop-ghost';
    cancel.textContent = msg.popCancel;
    cancel.addEventListener('click', closeSettings);
    const save = document.createElement('button');
    save.type = 'button';
    save.className = 'aix-btn aix-pop-save';
    save.textContent = msg.popSave;
    save.addEventListener('click', function () {
      ctx.onSave({ template: ta.value, autoSend: cb.checked });
      closeSettings();
    });
    row.appendChild(reset);
    row.appendChild(cancel);
    row.appendChild(save);

    pop.appendChild(title);
    pop.appendChild(label);
    pop.appendChild(ta);
    pop.appendChild(hint);
    pop.appendChild(auto);
    pop.appendChild(row);
    document.body.appendChild(pop);

    const r = anchor.getBoundingClientRect();
    const w = pop.offsetWidth;
    pop.style.left = Math.max(8, Math.min(r.left, window.innerWidth - w - 8)) + 'px';
    pop.style.top = (r.bottom + 6) + 'px';

    setTimeout(function () {
      document.addEventListener('mousedown', outside);
      document.addEventListener('keydown', onEsc);
    }, 0);
    function outside(e) {
      if (pop.contains(e.target) || anchor.contains(e.target)) return;
      closeSettings();
    }
    function onEsc(e) {
      if (e.key === 'Escape') closeSettings();
    }
    pop._teardown = function () {
      document.removeEventListener('mousedown', outside);
      document.removeEventListener('keydown', onEsc);
    };
    return pop;
  }

  function closeSettings() {
    const pop = document.getElementById('aix-pop');
    if (!pop) return;
    if (pop._teardown) pop._teardown();
    pop.remove();
  }

  return { run, isBusy, openSettings, closeSettings };
});
