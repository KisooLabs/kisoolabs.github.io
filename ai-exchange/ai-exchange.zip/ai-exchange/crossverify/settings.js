// chrome.storage.local wrapper for { template, autoSend }.
(function (root) {
  const core = root.CrossVerifyCore;
  const KEY = 'crossverify_settings';
  const listeners = [];

  // opts (optional) → core.mergeSettings: { defaultTemplate, knownDefaults }
  // — the hub passes the localized default template set (i18n).
  function load(opts) {
    return new Promise(function (resolve) {
      chrome.storage.local.get(KEY, function (obj) {
        resolve(core.mergeSettings(obj && obj[KEY], opts));
      });
    });
  }

  function save(partial, opts) {
    const merged = core.mergeSettings(partial, opts);
    return new Promise(function (resolve) {
      chrome.storage.local.set({ [KEY]: merged }, function () {
        listeners.forEach(function (fn) { fn(merged); });
        resolve(merged);
      });
    });
  }

  function onChange(fn) { listeners.push(fn); }

  root.CrossVerifySettings = { load: load, save: save, onChange: onChange };
})(globalThis);
