// Pure logic. No DOM, no chrome APIs. Works as a classic browser script
// (attaches to globalThis.CrossVerifyCore) and as a CommonJS module (tests).
(function (root, factory) {
  const api = factory();
  root.CrossVerifyCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  // Superseded defaults, kept verbatim: a stored template equal to one of
  // these is an untouched old default, not a user customization, so
  // mergeSettings upgrades it to the current DEFAULT_TEMPLATE (2026-07-15).
  const LEGACY_TEMPLATES = [
`다음은 같은 질문에 대한 다른 LLM 모델의 답변입니다.
맹목적으로 동의하지 말고, 비판적이고 독립적으로 검증해 주세요.
사실관계·논리·근거를 따져 동의하는 부분과 동의하지 않는 부분을 이유와 함께 제시해 주세요.

---
{{answer}}`
  ];

  // User spec (2026-07-09 inbox): compare answers critically, independently,
  // open-mindedly; verdict right/wrong, research the uncertain — the goal is a
  // BETTER final answer to the user's original question, not a review.
  const DEFAULT_TEMPLATE =
`다음은 같은 질문에 대한 다른 LLM의 답변입니다.
서로의 대답을 비교하고 비판적·독립적·개방적으로 엄밀하게 검토해, 맞는 부분은 맞다, 틀린 부분은 틀리다고 밝히고, 불확실한 부분은 더 리서치해서 종합해 주세요.
다른 LLM 답변의 맞고 틀림을 평가하는 데 그치지 말고, 그것을 참고해 내가 최초에 궁금해했던 질문에 대해 더 나은 최종 답변을 주는 것이 목표입니다.

---
{{answer}}`;

  const DEFAULT_SETTINGS = { template: DEFAULT_TEMPLATE, autoSend: true };

  // Combine the OTHER panels' answers into the single string the template's
  // {{answer}} slot receives. One other answer → injected raw (exact 2-panel
  // parity: there is no ambiguity about whose answer it is). Two or more →
  // each headed by its model name so the receiving model can tell the sources
  // apart. Empty/whitespace answers are dropped; an all-empty set yields ''.
  function combineAnswers(list) {
    const items = (list || []).filter(function (it) {
      return it && typeof it.text === 'string' && it.text.trim().length > 0;
    });
    if (items.length === 0) return '';
    if (items.length === 1) return items[0].text;
    return items.map(function (it) {
      return '### ' + (it.name || 'LLM') + '\n' + it.text;
    }).join('\n\n');
  }

  // answer may be a plain string (2-panel legacy callers) or an array of
  // { name, text } (N-panel cross-feed) — the array form is combined here.
  function wrapAnswer(template, answer) {
    const text = Array.isArray(answer) ? combineAnswers(answer) : answer;
    const tpl = (typeof template === 'string' && template.length) ? template : DEFAULT_TEMPLATE;
    if (tpl.indexOf('{{answer}}') !== -1) return tpl.split('{{answer}}').join(text);
    return tpl + '\n\n' + text;
  }

  // opts (2026-07-24, i18n): { defaultTemplate, knownDefaults } lets the
  // caller localize the default template — knownDefaults lists every
  // language's default so an untouched default stored under a previous
  // language still counts as "not customized" and re-localizes.
  function mergeSettings(stored, opts) {
    const s = stored || {};
    const o = opts || {};
    const defaults = LEGACY_TEMPLATES.concat(o.knownDefaults || []);
    const isCustom = typeof s.template === 'string' && s.template.length > 0
      && defaults.indexOf(s.template) === -1;
    return {
      template: isCustom ? s.template : (o.defaultTemplate || DEFAULT_SETTINGS.template),
      autoSend: (typeof s.autoSend === 'boolean') ? s.autoSend : DEFAULT_SETTINGS.autoSend
    };
  }

  function orderByPosition(items) {
    return items.slice().sort((a, b) => a.x - b.x);
  }

  function pickPlatform(hostname, table) {
    const h = String(hostname || '').toLowerCase();
    for (let i = 0; i < table.length; i++) {
      const suf = table[i].hostSuffix;
      if (suf && (h === suf || h.endsWith('.' + suf))) return table[i];
    }
    return null;
  }

  function panelGate(count) {
    if (count >= 2) return { enabled: true, reason: '' };
    return { enabled: false, reason: '패널이 2개 이상일 때 동작합니다.' };
  }

  function normalizeLabel(s) {
    return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function matchLabel(text, labelSet) {
    const t = normalizeLabel(text);
    if (!t) return false;
    for (let i = 0; i < labelSet.length; i++) {
      if (normalizeLabel(labelSet[i]) === t) return true;
    }
    return false;
  }

  // Choose the chat composer (or its send button) from all elements matching a
  // platform input/send selector, given in document order. The composer is
  // never inside a rendered answer and is always last in the DOM (every
  // conversation turn precedes it), so: drop any candidate the predicate marks
  // as inside a response body, then take the last survivor. Returns null when
  // none qualify — never fall back to an editable/button embedded in an answer
  // (typing/clicking there would send into the reply, not the composer).
  function lastOutsideResponse(candidates, isInResponse) {
    const list = candidates || [];
    const inResp = typeof isInResponse === 'function' ? isInResponse : function () { return false; };
    let picked = null;
    for (let i = 0; i < list.length; i++) {
      if (!inResp(list[i])) picked = list[i];
    }
    return picked;
  }

  // Render a conversation export as one markdown document. Serves both export
  // scopes: `panels` is [{ platform, turns: [{ role, text }] }] — full history
  // for READ_CONVERSATION, or a single assistant turn per panel for the latest
  // exchange. A user turn is labelled "You", any other by its platform name.
  // meta: { title, exportedAt }.
  function buildConversationMarkdown(panels, meta) {
    const list = panels || [];
    const m = meta || {};
    const out = [];
    out.push('# ' + (m.title || 'AI Exchange'));
    if (m.exportedAt) out.push('_Exported ' + m.exportedAt + '_');
    for (let i = 0; i < list.length; i++) {
      const p = list[i] || {};
      const name = p.platform || 'Panel';
      const turns = p.turns || [];
      out.push('');
      out.push('## ' + name);
      for (let j = 0; j < turns.length; j++) {
        const t = turns[j] || {};
        out.push('');
        out.push('**' + (t.role === 'user' ? 'You' : name) + ':**');
        out.push('');
        out.push(String(t.text == null ? '' : t.text).trim());
      }
    }
    return out.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
  }

  // Human-readable reasons for per-panel RPC failures, shown in the toast so a
  // failing panel names itself (anonymous aborts made selector breaks undiagnosable).
  const ERROR_LABELS = {
    NO_RESPONSE: '답변 없음',
    TIMEOUT: '응답 시간 초과',
    NO_INPUT: '입력창 없음',
    NO_SEND: '전송 불가'
  };

  // failures: [{ name, error }] → "Claude(답변 없음), Grok(응답 시간 초과)".
  // Unknown error codes pass through raw. Order preserved. Empty array → ''.
  // labels (2026-07-24, i18n): optional {CODE: text} override — hub passes
  // the localized set; the Korean ERROR_LABELS stay as the fallback.
  function describePanelFailures(failures, labels) {
    const map = labels || ERROR_LABELS;
    return (failures || []).map(function (f) {
      return (f.name || '?') + '(' + (map[f.error] || ERROR_LABELS[f.error] || f.error || '?') + ')';
    }).join(', ');
  }

  return {
    DEFAULT_TEMPLATE, LEGACY_TEMPLATES, DEFAULT_SETTINGS, wrapAnswer, combineAnswers,
    mergeSettings, orderByPosition, pickPlatform, panelGate, normalizeLabel, matchLabel,
    lastOutsideResponse, buildConversationMarkdown, ERROR_LABELS, describePanelFailures
  };
});
