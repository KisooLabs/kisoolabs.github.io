// src/popup.js — manual-mode popup controller.
'use strict';
const $ = (id) => document.getElementById(id);
const state = { url: '', bytes: null, filename: 'document.pdf', sizes: [], pages: 0, remove: new Set() };

function showStatus(msg, isErr) { const s = $('status'); s.textContent = msg; s.className = isErr ? 'err' : ''; s.classList.remove('hidden'); }

function looksLikePdf(url, contentType, buf) {
  if (contentType && contentType.includes('pdf')) return true;
  if (/\.pdf(\?|#|$)/i.test(url)) return true;
  const b = new Uint8Array(buf.slice(0, 5));
  return b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46 && b[4] === 0x2d; // %PDF-
}

async function loadActivePdf() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url) { showStatus('No active tab.', true); return false; }
  state.url = tab.url;
  if (state.url.startsWith('file://')) {
    // requires the user's "Allow access to file URLs" toggle
  }
  try {
    const res = await fetch(state.url, { credentials: 'include' });
    const ct = (res.headers.get('content-type') || '').toLowerCase();
    const buf = await res.arrayBuffer();
    if (!res.ok || !looksLikePdf(state.url, ct, buf)) {
      showStatus('This tab is not a PDF. Open a PDF, then click the icon.', true); return false;
    }
    state.bytes = new Uint8Array(buf);
    state.filename = PPR.parseFilename(res.headers.get('content-disposition'), fallbackName(state.url));
    return true;
  } catch (e) {
    if (state.url.startsWith('file://')) {
      showStatus('Can\'t read local file. Enable "Allow access to file URLs" for this extension.', true);
    } else {
      showStatus('Couldn\'t read the PDF (' + (e.message || e) + ').', true);
    }
    return false;
  }
}

function fallbackName(url) {
  try { const p = new URL(url).pathname.split('/').pop() || 'document'; return decodeURIComponent(p); }
  catch (_) { return 'document'; }
}

function buildCells() {
  const grid = $('grid'); grid.innerHTML = '';
  for (let i = 1; i <= state.pages; i++) {
    const t = document.createElement('div');
    t.className = 'thumb' + (state.remove.has(i) ? ' mark' : '');
    t.dataset.page = i;
    t.innerHTML = '<div class="page">' + i + '</div><span class="no">' + i + '</span>';
    t.addEventListener('click', () => toggle(i, t));
    grid.appendChild(t);
  }
}

async function renderGrid() {
  const grid = $('grid');
  let pdf = null;
  try {
    pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('lib/pdfjs/pdf.worker.min.js');
    pdf = await pdfjsLib.getDocument({ data: state.bytes.slice() }).promise;
    state.pages = pdf.numPages;
  } catch (e) {
    // fallback: use pdf-lib's page count, numbered chips only
    state.pages = state.sizes.length || 1;
    grid.classList.add('chip-fallback');
    buildCells();
    return;
  }
  buildCells();
  const io = new IntersectionObserver((entries, obs) => {
    entries.forEach((en) => { if (en.isIntersecting) { obs.unobserve(en.target); drawThumb(pdf, en.target); } });
  }, { root: grid, rootMargin: '120px' });
  grid.querySelectorAll('.thumb').forEach((t) => io.observe(t));
}

async function drawThumb(pdf, cell) {
  try {
    const page = await pdf.getPage(+cell.dataset.page);
    const vp0 = page.getViewport({ scale: 1 });
    const scale = 150 / vp0.width; // ~150px wide thumbs
    const vp = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = vp.width; canvas.height = vp.height;
    await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
    const box = cell.querySelector('.page'); box.textContent = ''; box.appendChild(canvas);
  } catch (_) { /* leave the numbered placeholder */ }
}

function toggle(page, cell) {
  if (state.remove.has(page)) state.remove.delete(page); else state.remove.add(page);
  cell.classList.toggle('mark'); updateCount();
}
function quick(kind) {
  state.remove = new Set();
  if (kind === 'all') for (let i = 1; i <= state.pages; i++) state.remove.add(i);
  else if (kind === 'cover') state.remove.add(1);
  else if (kind === 'last') state.remove.add(state.pages);
  // 'clear' leaves the set empty
  $('grid').querySelectorAll('.thumb').forEach((t) => t.classList.toggle('mark', state.remove.has(+t.dataset.page)));
  updateCount();
}
function updateCount() {
  const rm = state.remove, keep = state.pages - rm.size, btn = $('btn'), hint = $('hint'), count = $('count');
  if (rm.size === 0) {
    count.innerHTML = 'Nothing selected — all <b>' + state.pages + '</b> pages kept';
    btn.disabled = true; hint.className = 'hintline'; hint.textContent = 'Saves a new copy · original untouched';
  } else if (keep === 0) {
    count.innerHTML = '<span class="r">All ' + state.pages + ' pages selected</span>';
    btn.disabled = true; hint.className = 'hintline warn'; hint.textContent = 'Keep at least one page.';
  } else {
    const list = [...rm].sort((a, b) => a - b).join(', ');
    count.innerHTML = 'Removing <span class="r">' + rm.size + '</span> (p. ' + list + ') · <span class="k">' + keep + '</span> pages remain';
    btn.disabled = false; btn.textContent = 'Remove ' + rm.size + ' & download';
    hint.className = 'hintline'; hint.textContent = 'Saves a new copy · original untouched';
  }
}
function wireQuick() { $('quick').querySelectorAll('button').forEach((b) => b.addEventListener('click', () => quick(b.dataset.q))); }

function bytesToDataUrl(bytes) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result); fr.onerror = () => reject(fr.error);
    fr.readAsDataURL(new Blob([bytes], { type: 'application/pdf' }));
  });
}
const MAX_BYTES = 90 * 1024 * 1024; // ~90MB; data: URL hand-off gets unreliable beyond this
async function onRemove() {
  const btn = $('btn'); btn.disabled = true; const prev = btn.textContent; btn.textContent = 'Working…';
  try {
    const { bytes } = await PPR.removePages(state.bytes, [...state.remove]);
    if (bytes.length > MAX_BYTES) {
      showStatus('This PDF is too large to save this way (' + Math.round(bytes.length / 1048576) + ' MB).', true);
      btn.disabled = false; btn.textContent = prev;
      return;
    }
    const dataUrl = await bytesToDataUrl(bytes);
    const resp = await chrome.runtime.sendMessage({ type: 'save-pdf', dataUrl, filename: state.filename });
    if (resp && resp.ok) { showStatus('Saved to Downloads: ' + state.filename); window.close(); }
    else { showStatus('Save failed: ' + ((resp && resp.error) || ''), true); btn.disabled = false; btn.textContent = prev; }
  } catch (e) { showStatus('Failed: ' + (e.message || e), true); btn.disabled = false; btn.textContent = prev; }
}
function reveal() { ['quick', 'grid', 'count', 'btn', 'hint'].forEach((id) => $(id).classList.remove('hidden')); $('status').classList.add('hidden'); }

async function boot() {
  try { await initJstorRow(); } catch (_) { /* non-essential JSTOR opt-in row; never block the popup */ }
  const ok = await loadActivePdf();
  if (!ok) return;
  $('file').textContent = state.filename;
  try { state.sizes = await PPR.readPageSizes(state.bytes); } catch (_) { state.sizes = []; }
  await renderGrid();
  $('file').textContent = state.filename + ' · ' + state.pages + ' pages';
  applyPreset();      // Task 12
  wireQuick();
  $('btn').addEventListener('click', onRemove);
  updateCount();
  reveal();
}
function selectPages(pages1) {
  state.remove = new Set(pages1.filter((n) => n >= 1 && n <= state.pages));
  $('grid').querySelectorAll('.thumb').forEach((t) => t.classList.toggle('mark', state.remove.has(+t.dataset.page)));
  updateCount();
}
function applyPreset() {
  const preset = PPR.matchPreset({ url: state.url, pageSizes: state.sizes });
  if (!preset) return;
  const isJstor = preset.id === 'jstor';
  const banner = $('banner');
  banner.innerHTML =
    '<div style="font-size:15px">💡</div><div class="st"><b>' +
    (isJstor ? 'Looks like a JSTOR download.' : 'Page 1 looks different.') +
    '</b><small>' + (isJstor ? 'Page 1 is usually a cover. ' : 'It may be a cover or banner. ') +
    '<a id="applyPreset">Remove page ' + preset.action.remove.join(', ') + ' ›</a></small></div>';
  banner.classList.remove('hidden');
  banner.querySelector('#applyPreset').addEventListener('click', () => selectPages(preset.action.remove));
}
async function initJstorRow() {
  const row = $('jstorRow');
  const has = await chrome.permissions.contains({ origins: ['https://www.jstor.org/*'] });
  if (has) return;
  row.classList.remove('hidden');
  $('jstorEnable').addEventListener('click', async () => {
    const granted = await chrome.permissions.request({ origins: ['https://www.jstor.org/*'] });
    if (granted) row.classList.add('hidden');
  });
}
document.addEventListener('DOMContentLoaded', boot);
