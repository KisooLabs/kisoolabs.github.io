// UI-string catalogs for everything crossverify injects (hub chrome, toasts,
// settings popover, export titles, Claude history button, and the default
// exchange-prompt template). Follows options.language (the 🌐 menu); 'system'
// resolves against the browser UI language. Pure data + tiny resolver — no
// DOM, no chrome APIs. Works as a classic browser script (attaches to
// globalThis.CrossVerifyI18N) and as a CommonJS module (tests).
//
// Language codes mirror the bundled app's own enum (chunk-a682ba63.js $d):
// en ko ja zh-CN zh-TW es fr de ru ar pt-PT pt-BR. Every catalog must carry
// the FULL en key set (tests/i18n.test.js pins parity); en is also the
// runtime fallback merge, so a missing key degrades to English, never blank.
(function (root, factory) {
  const api = factory();
  root.CrossVerifyI18N = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const MESSAGES = {
    en: {
      exchange: 'Exchange', export: 'Export', exportTip: 'Save the conversation as .md',
      exportFull: 'Full conversation', exportLatest: 'Latest answers',
      settingsTip: 'Exchange settings', panelOpen: 'Open in new window', panelClose: 'Close panel',
      panelReload: 'Reload panel', panelFullscreen: 'Fullscreen',
      send: "Send", newChat: "New Chat", addApp: "Add panel",
      composerPlaceholder: "Send to every panel…", broadcastEmpty: "Type something first", broadcastDone: "Sent to {n} panels ✓",
      langTip: 'App language', langSystem: 'System (browser language)',
      gateNeed2: 'Works with 2 or more panels.',
      unsupported: 'This platform is not supported for exchange yet',
      readFail: 'Read failed: ', fillFail: 'Fill failed: ', sendFail: 'Send failed: ',
      filled: 'Filled every composer',
      allDone: 'Cross-fill + auto-send complete ✓',
      partial: 'Not sent: {panels} (reload that panel, then try again)',
      fail: 'Failed: ', saved: 'Settings saved',
      noExportPanels: 'No supported panels to export', noConversations: 'No conversations to read',
      exportDone: 'Export complete ✓ ({n} panels)', exportFail: 'Export failed: ',
      langFail: 'Language change failed: ',
      popTitle: 'Exchange settings', popTemplate: 'Exchange prompt template',
      popHint: "The other models' latest answers replace {{answer}}.",
      popAutoSend: 'Auto-send', popReset: 'Reset to default', popCancel: 'Cancel',
      popSave: 'Save',
      failNoResponse: 'no answer', failTimeout: 'timed out',
      failNoInput: 'no composer', failNoSend: 'cannot send',
      exportTitleFull: 'AI Exchange — Conversation log', exportTitleLatest: 'AI Exchange — Latest exchange',
      historyShow: 'Chat history (Recents)', historyHide: 'Close history (new chat)', historyAria: 'Chat history',
      defaultTemplate:
`Below are other LLMs' answers to the same question.
Compare them and examine them rigorously — critically, independently, and open-mindedly: state clearly what is right and what is wrong, and research anything uncertain before synthesizing.
Do not stop at judging the other answers — use them to give a better final answer to my original question.

---
{{answer}}`
    },
    ko: {
      exchange: '교환', export: '내보내기', exportTip: '대화를 .md로 저장',
      exportFull: '전체 대화', exportLatest: '최신 답변',
      settingsTip: 'Exchange 설정', panelOpen: '새 창에서 열기', panelClose: '패널 닫기',
      panelReload: '패널 새로고침', panelFullscreen: '전체화면',
      send: "보내기", newChat: "새 채팅", addApp: "패널 추가",
      composerPlaceholder: "모든 패널로 보내기…", broadcastEmpty: "먼저 내용을 입력하세요", broadcastDone: "{n}개 패널로 전송 ✓",
      langTip: '앱 언어', langSystem: '시스템 (브라우저 언어)',
      gateNeed2: '패널이 2개 이상일 때 동작합니다.',
      unsupported: '이 플랫폼은 아직 교차검증 미지원',
      readFail: '읽기 실패: ', fillFail: '입력 실패: ', sendFail: '전송 실패: ',
      filled: '각 입력창에 채웠습니다',
      allDone: '교차 입력 + 자동 전송 완료 ✓',
      partial: '전송되지 않은 패널: {panels} (해당 패널을 리로드한 뒤 다시 시도하세요)',
      fail: '실패: ', saved: '설정 저장됨',
      noExportPanels: '내보낼 지원 패널이 없습니다', noConversations: '읽을 대화가 없습니다',
      exportDone: '내보내기 완료 ✓ ({n}개 패널)', exportFail: '내보내기 실패: ',
      langFail: '언어 설정 실패: ',
      popTitle: 'Exchange 설정', popTemplate: '교환 프롬프트 템플릿',
      popHint: '{{answer}} 자리에 상대 모델의 최신 답변이 들어갑니다.',
      popAutoSend: '자동 전송', popReset: '기본값으로', popCancel: '취소',
      popSave: '저장',
      failNoResponse: '답변 없음', failTimeout: '응답 시간 초과',
      failNoInput: '입력창 없음', failNoSend: '전송 불가',
      exportTitleFull: 'AI Exchange — 대화 기록', exportTitleLatest: 'AI Exchange — 최신 교환',
      historyShow: '대화 기록 (Recents)', historyHide: '대화 기록 닫기 (새 대화)', historyAria: '대화 기록',
      // MUST stay byte-identical to core.DEFAULT_TEMPLATE (tests pin it):
      // mergeSettings treats any catalog default as "untouched by the user".
      defaultTemplate:
`다음은 같은 질문에 대한 다른 LLM의 답변입니다.
서로의 대답을 비교하고 비판적·독립적·개방적으로 엄밀하게 검토해, 맞는 부분은 맞다, 틀린 부분은 틀리다고 밝히고, 불확실한 부분은 더 리서치해서 종합해 주세요.
다른 LLM 답변의 맞고 틀림을 평가하는 데 그치지 말고, 그것을 참고해 내가 최초에 궁금해했던 질문에 대해 더 나은 최종 답변을 주는 것이 목표입니다.

---
{{answer}}`
    },
    ja: {
      exchange: '交換', export: 'エクスポート', exportTip: '会話を .md で保存',
      exportFull: '会話全体', exportLatest: '最新の回答',
      settingsTip: 'Exchange 設定', panelOpen: '新しいウィンドウで開く', panelClose: 'パネルを閉じる',
      panelReload: 'パネルを再読み込み', panelFullscreen: '全画面',
      send: "送信", newChat: "新しいチャット", addApp: "パネルを追加",
      composerPlaceholder: "すべてのパネルに送信…", broadcastEmpty: "先に入力してください", broadcastDone: "{n}個のパネルに送信 ✓",
      langTip: 'アプリの言語', langSystem: 'システム（ブラウザの言語）',
      gateNeed2: 'パネルが2つ以上のときに動作します。',
      unsupported: 'このプラットフォームは交換にまだ対応していません',
      readFail: '読み取り失敗: ', fillFail: '入力失敗: ', sendFail: '送信失敗: ',
      filled: '各入力欄に入力しました',
      allDone: '相互入力 + 自動送信 完了 ✓',
      partial: '未送信のパネル: {panels}（該当パネルを再読み込みして再試行してください）',
      fail: '失敗: ', saved: '設定を保存しました',
      noExportPanels: 'エクスポートできるパネルがありません', noConversations: '読み取れる会話がありません',
      exportDone: 'エクスポート完了 ✓（{n}パネル）', exportFail: 'エクスポート失敗: ',
      langFail: '言語設定に失敗しました: ',
      popTitle: 'Exchange 設定', popTemplate: '交換プロンプトのテンプレート',
      popHint: '{{answer}} の位置に相手モデルの最新回答が入ります。',
      popAutoSend: '自動送信', popReset: '既定値に戻す', popCancel: 'キャンセル',
      popSave: '保存',
      failNoResponse: '回答なし', failTimeout: '応答タイムアウト',
      failNoInput: '入力欄なし', failNoSend: '送信不可',
      exportTitleFull: 'AI Exchange — 会話ログ', exportTitleLatest: 'AI Exchange — 最新の交換',
      historyShow: 'チャット履歴 (Recents)', historyHide: '履歴を閉じる（新しいチャット）', historyAria: 'チャット履歴',
      defaultTemplate:
`以下は同じ質問に対する他のLLMの回答です。
互いの回答を比較し、批判的・独立的・開放的に厳密に検討して、正しい部分は正しい、誤っている部分は誤っていると明示し、不確かな部分はさらに調べて総合してください。
他のLLMの回答の正誤評価にとどまらず、それを参考に、私が最初に知りたかった質問へのより良い最終回答を出すことが目標です。

---
{{answer}}`
    },
    'zh-CN': {
      exchange: '交换', export: '导出', exportTip: '将对话保存为 .md',
      exportFull: '完整对话', exportLatest: '最新回答',
      settingsTip: 'Exchange 设置', panelOpen: '在新窗口打开', panelClose: '关闭面板',
      panelReload: '重新加载面板', panelFullscreen: '全屏',
      send: "发送", newChat: "新对话", addApp: "添加面板",
      composerPlaceholder: "发送到所有面板…", broadcastEmpty: "请先输入内容", broadcastDone: "已发送到 {n} 个面板 ✓",
      langTip: '应用语言', langSystem: '系统（浏览器语言）',
      gateNeed2: '需要 2 个及以上面板才能使用。',
      unsupported: '该平台暂不支持交换',
      readFail: '读取失败：', fillFail: '填入失败：', sendFail: '发送失败：',
      filled: '已填入所有输入框',
      allDone: '交叉填入 + 自动发送完成 ✓',
      partial: '未发送的面板：{panels}（请重新加载该面板后重试）',
      fail: '失败：', saved: '设置已保存',
      noExportPanels: '没有可导出的面板', noConversations: '没有可读取的对话',
      exportDone: '导出完成 ✓（{n} 个面板）', exportFail: '导出失败：',
      langFail: '语言设置失败：',
      popTitle: 'Exchange 设置', popTemplate: '交换提示词模板',
      popHint: '{{answer}} 处将替换为其他模型的最新回答。',
      popAutoSend: '自动发送', popReset: '恢复默认', popCancel: '取消',
      popSave: '保存',
      failNoResponse: '无回答', failTimeout: '响应超时',
      failNoInput: '无输入框', failNoSend: '无法发送',
      exportTitleFull: 'AI Exchange — 对话记录', exportTitleLatest: 'AI Exchange — 最新交换',
      historyShow: '聊天记录 (Recents)', historyHide: '关闭记录（新聊天）', historyAria: '聊天记录',
      defaultTemplate:
`以下是其他 LLM 对同一问题的回答。
请对比这些回答，并以批判、独立、开放的态度严格审视：指出哪些部分正确、哪些部分错误，对不确定的内容进一步研究后加以综合。
不要止步于评判其他 LLM 回答的对错，而要参考它们，对我最初的问题给出更好的最终回答。

---
{{answer}}`
    },
    'zh-TW': {
      exchange: '交換', export: '匯出', exportTip: '將對話儲存為 .md',
      exportFull: '完整對話', exportLatest: '最新回答',
      settingsTip: 'Exchange 設定', panelOpen: '在新視窗開啟', panelClose: '關閉面板',
      panelReload: '重新載入面板', panelFullscreen: '全螢幕',
      send: "發送", newChat: "新聊天", addApp: "新增面板",
      composerPlaceholder: "傳送到所有面板…", broadcastEmpty: "請先輸入內容", broadcastDone: "已傳送到 {n} 個面板 ✓",
      langTip: '應用程式語言', langSystem: '系統（瀏覽器語言）',
      gateNeed2: '需要 2 個以上面板才能使用。',
      unsupported: '此平台尚不支援交換',
      readFail: '讀取失敗：', fillFail: '填入失敗：', sendFail: '傳送失敗：',
      filled: '已填入所有輸入框',
      allDone: '交叉填入 + 自動傳送完成 ✓',
      partial: '未傳送的面板：{panels}（請重新載入該面板後再試）',
      fail: '失敗：', saved: '設定已儲存',
      noExportPanels: '沒有可匯出的面板', noConversations: '沒有可讀取的對話',
      exportDone: '匯出完成 ✓（{n} 個面板）', exportFail: '匯出失敗：',
      langFail: '語言設定失敗：',
      popTitle: 'Exchange 設定', popTemplate: '交換提示詞範本',
      popHint: '{{answer}} 處會替換為其他模型的最新回答。',
      popAutoSend: '自動傳送', popReset: '恢復預設', popCancel: '取消',
      popSave: '儲存',
      failNoResponse: '無回答', failTimeout: '回應逾時',
      failNoInput: '無輸入框', failNoSend: '無法傳送',
      exportTitleFull: 'AI Exchange — 對話紀錄', exportTitleLatest: 'AI Exchange — 最新交換',
      historyShow: '聊天紀錄 (Recents)', historyHide: '關閉紀錄（新聊天）', historyAria: '聊天紀錄',
      defaultTemplate:
`以下是其他 LLM 對同一問題的回答。
請對比這些回答，並以批判、獨立、開放的態度嚴格檢視：指出哪些部分正確、哪些部分錯誤，對不確定的內容進一步研究後加以總結。
不要止步於評判其他 LLM 回答的對錯，而要參考它們，對我最初的問題給出更好的最終回答。

---
{{answer}}`
    },
    es: {
      exchange: 'Intercambiar', export: 'Exportar', exportTip: 'Guardar la conversación como .md',
      exportFull: 'Conversación completa', exportLatest: 'Últimas respuestas',
      settingsTip: 'Ajustes de Exchange', panelOpen: 'Abrir en ventana nueva', panelClose: 'Cerrar panel',
      panelReload: 'Recargar panel', panelFullscreen: 'Pantalla completa',
      send: "Enviar", newChat: "Nuevo Chat", addApp: "Añadir panel",
      composerPlaceholder: "Enviar a todos los paneles…", broadcastEmpty: "Escribe algo primero", broadcastDone: "Enviado a {n} paneles ✓",
      langTip: 'Idioma de la aplicación', langSystem: 'Sistema (idioma del navegador)',
      gateNeed2: 'Funciona con 2 o más paneles.',
      unsupported: 'Esta plataforma aún no es compatible con el intercambio',
      readFail: 'Error de lectura: ', fillFail: 'Error al rellenar: ', sendFail: 'Error al enviar: ',
      filled: 'Se rellenaron todos los campos',
      allDone: 'Intercambio + envío automático completados ✓',
      partial: 'Sin enviar: {panels} (recarga ese panel y vuelve a intentarlo)',
      fail: 'Error: ', saved: 'Ajustes guardados',
      noExportPanels: 'No hay paneles compatibles para exportar', noConversations: 'No hay conversaciones que leer',
      exportDone: 'Exportación completada ✓ ({n} paneles)', exportFail: 'Error al exportar: ',
      langFail: 'Error al cambiar el idioma: ',
      popTitle: 'Ajustes de Exchange', popTemplate: 'Plantilla del prompt de intercambio',
      popHint: 'Las últimas respuestas de los otros modelos sustituyen a {{answer}}.',
      popAutoSend: 'Envío automático', popReset: 'Restablecer', popCancel: 'Cancelar',
      popSave: 'Guardar',
      failNoResponse: 'sin respuesta', failTimeout: 'tiempo agotado',
      failNoInput: 'sin campo de entrada', failNoSend: 'no se puede enviar',
      exportTitleFull: 'AI Exchange — Registro de conversación', exportTitleLatest: 'AI Exchange — Último intercambio',
      historyShow: 'Historial de chats (Recents)', historyHide: 'Cerrar historial (chat nuevo)', historyAria: 'Historial de chats',
      defaultTemplate:
`A continuación se muestran las respuestas de otros LLM a la misma pregunta.
Compáralas y examínalas con rigor —de forma crítica, independiente y abierta—: indica qué partes son correctas y cuáles no, e investiga lo que sea incierto antes de sintetizar.
No te limites a juzgar las otras respuestas: úsalas para dar una mejor respuesta final a mi pregunta original.

---
{{answer}}`
    },
    fr: {
      exchange: 'Échanger', export: 'Exporter', exportTip: 'Enregistrer la conversation en .md',
      exportFull: 'Conversation complète', exportLatest: 'Dernières réponses',
      settingsTip: "Paramètres d'Exchange", panelOpen: 'Ouvrir dans une nouvelle fenêtre', panelClose: 'Fermer le panneau',
      panelReload: 'Recharger le panneau', panelFullscreen: 'Plein écran',
      send: "Envoyer", newChat: "Nouveau Chat", addApp: "Ajouter un panneau",
      composerPlaceholder: "Envoyer à tous les panneaux…", broadcastEmpty: "Saisissez d'abord un texte", broadcastDone: "Envoyé à {n} panneaux ✓",
      langTip: "Langue de l'application", langSystem: 'Système (langue du navigateur)',
      gateNeed2: 'Fonctionne avec 2 panneaux ou plus.',
      unsupported: "Cette plateforme n'est pas encore prise en charge pour l'échange",
      readFail: 'Échec de lecture : ', fillFail: 'Échec de remplissage : ', sendFail: "Échec d'envoi : ",
      filled: 'Tous les champs ont été remplis',
      allDone: 'Remplissage croisé + envoi automatique terminés ✓',
      partial: 'Non envoyé : {panels} (rechargez ce panneau, puis réessayez)',
      fail: 'Échec : ', saved: 'Paramètres enregistrés',
      noExportPanels: 'Aucun panneau compatible à exporter', noConversations: 'Aucune conversation à lire',
      exportDone: 'Exportation terminée ✓ ({n} panneaux)', exportFail: "Échec de l'exportation : ",
      langFail: 'Échec du changement de langue : ',
      popTitle: "Paramètres d'Exchange", popTemplate: "Modèle de prompt d'échange",
      popHint: 'Les dernières réponses des autres modèles remplacent {{answer}}.',
      popAutoSend: 'Envoi automatique', popReset: 'Réinitialiser', popCancel: 'Annuler',
      popSave: 'Enregistrer',
      failNoResponse: 'pas de réponse', failTimeout: 'délai dépassé',
      failNoInput: 'pas de champ de saisie', failNoSend: 'envoi impossible',
      exportTitleFull: 'AI Exchange — Journal de conversation', exportTitleLatest: 'AI Exchange — Dernier échange',
      historyShow: 'Historique des discussions (Recents)', historyHide: "Fermer l'historique (nouvelle discussion)", historyAria: 'Historique des discussions',
      defaultTemplate:
`Voici les réponses d'autres LLM à la même question.
Compare-les et examine-les rigoureusement — de manière critique, indépendante et ouverte : indique clairement ce qui est juste et ce qui est faux, et approfondis ce qui est incertain avant de faire la synthèse.
Ne te contente pas de juger les autres réponses : utilise-les pour donner une meilleure réponse finale à ma question initiale.

---
{{answer}}`
    },
    de: {
      exchange: 'Austauschen', export: 'Exportieren', exportTip: 'Unterhaltung als .md speichern',
      exportFull: 'Gesamte Unterhaltung', exportLatest: 'Neueste Antworten',
      settingsTip: 'Exchange-Einstellungen', panelOpen: 'In neuem Fenster öffnen', panelClose: 'Panel schließen',
      panelReload: 'Panel neu laden', panelFullscreen: 'Vollbild',
      send: "Senden", newChat: "Neuer Chat", addApp: "Panel hinzufügen",
      composerPlaceholder: "An alle Panels senden…", broadcastEmpty: "Bitte zuerst etwas eingeben", broadcastDone: "An {n} Panels gesendet ✓",
      langTip: 'App-Sprache', langSystem: 'System (Browsersprache)',
      gateNeed2: 'Funktioniert mit 2 oder mehr Panels.',
      unsupported: 'Diese Plattform wird für den Austausch noch nicht unterstützt',
      readFail: 'Lesen fehlgeschlagen: ', fillFail: 'Einfügen fehlgeschlagen: ', sendFail: 'Senden fehlgeschlagen: ',
      filled: 'Alle Eingabefelder wurden befüllt',
      allDone: 'Kreuz-Einfügen + Auto-Senden abgeschlossen ✓',
      partial: 'Nicht gesendet: {panels} (Panel neu laden und erneut versuchen)',
      fail: 'Fehlgeschlagen: ', saved: 'Einstellungen gespeichert',
      noExportPanels: 'Keine unterstützten Panels zum Exportieren', noConversations: 'Keine Unterhaltungen zum Lesen',
      exportDone: 'Export abgeschlossen ✓ ({n} Panels)', exportFail: 'Export fehlgeschlagen: ',
      langFail: 'Sprachwechsel fehlgeschlagen: ',
      popTitle: 'Exchange-Einstellungen', popTemplate: 'Austausch-Prompt-Vorlage',
      popHint: 'Die neuesten Antworten der anderen Modelle ersetzen {{answer}}.',
      popAutoSend: 'Automatisch senden', popReset: 'Zurücksetzen', popCancel: 'Abbrechen',
      popSave: 'Speichern',
      failNoResponse: 'keine Antwort', failTimeout: 'Zeitüberschreitung',
      failNoInput: 'kein Eingabefeld', failNoSend: 'Senden nicht möglich',
      exportTitleFull: 'AI Exchange — Gesprächsprotokoll', exportTitleLatest: 'AI Exchange — Letzter Austausch',
      historyShow: 'Chatverlauf (Recents)', historyHide: 'Verlauf schließen (neuer Chat)', historyAria: 'Chatverlauf',
      defaultTemplate:
`Nachfolgend die Antworten anderer LLMs auf dieselbe Frage.
Vergleiche sie und prüfe sie streng — kritisch, unabhängig und offen: Benenne klar, was richtig und was falsch ist, und recherchiere Unsicheres, bevor du zusammenfasst.
Bleib nicht bei der Bewertung der anderen Antworten stehen — nutze sie, um eine bessere endgültige Antwort auf meine ursprüngliche Frage zu geben.

---
{{answer}}`
    },
    ru: {
      exchange: 'Обмен', export: 'Экспорт', exportTip: 'Сохранить беседу в .md',
      exportFull: 'Вся беседа', exportLatest: 'Последние ответы',
      settingsTip: 'Настройки Exchange', panelOpen: 'Открыть в новом окне', panelClose: 'Закрыть панель',
      panelReload: 'Перезагрузить панель', panelFullscreen: 'Полный экран',
      send: "Отправить", newChat: "Новый чат", addApp: "Добавить панель",
      composerPlaceholder: "Отправить во все панели…", broadcastEmpty: "Сначала введите текст", broadcastDone: "Отправлено в {n} панелей ✓",
      langTip: 'Язык приложения', langSystem: 'Системный (язык браузера)',
      gateNeed2: 'Работает при 2 и более панелях.',
      unsupported: 'Эта платформа пока не поддерживает обмен',
      readFail: 'Ошибка чтения: ', fillFail: 'Ошибка ввода: ', sendFail: 'Ошибка отправки: ',
      filled: 'Все поля ввода заполнены',
      allDone: 'Перекрёстный ввод + автоотправка завершены ✓',
      partial: 'Не отправлено: {panels} (перезагрузите эту панель и повторите)',
      fail: 'Ошибка: ', saved: 'Настройки сохранены',
      noExportPanels: 'Нет панелей для экспорта', noConversations: 'Нет бесед для чтения',
      exportDone: 'Экспорт завершён ✓ ({n} панелей)', exportFail: 'Ошибка экспорта: ',
      langFail: 'Не удалось сменить язык: ',
      popTitle: 'Настройки Exchange', popTemplate: 'Шаблон промпта обмена',
      popHint: 'Вместо {{answer}} подставляются последние ответы других моделей.',
      popAutoSend: 'Автоотправка', popReset: 'Сбросить', popCancel: 'Отмена',
      popSave: 'Сохранить',
      failNoResponse: 'нет ответа', failTimeout: 'время истекло',
      failNoInput: 'нет поля ввода', failNoSend: 'отправка невозможна',
      exportTitleFull: 'AI Exchange — Журнал беседы', exportTitleLatest: 'AI Exchange — Последний обмен',
      historyShow: 'История чатов (Recents)', historyHide: 'Закрыть историю (новый чат)', historyAria: 'История чатов',
      defaultTemplate:
`Ниже приведены ответы других LLM на тот же вопрос.
Сравни их и строго проверь — критически, независимо и непредвзято: чётко укажи, что верно, а что нет, а неясное дополнительно исследуй и обобщи.
Не ограничивайся оценкой чужих ответов — используй их, чтобы дать лучший итоговый ответ на мой исходный вопрос.

---
{{answer}}`
    },
    ar: {
      exchange: 'تبادل', export: 'تصدير', exportTip: 'حفظ المحادثة بصيغة ‎.md',
      exportFull: 'المحادثة كاملة', exportLatest: 'أحدث الإجابات',
      settingsTip: 'إعدادات Exchange', panelOpen: 'فتح في نافذة جديدة', panelClose: 'إغلاق اللوحة',
      panelReload: 'إعادة تحميل اللوحة', panelFullscreen: 'ملء الشاشة',
      send: "إرسال", newChat: "دردشة جديدة", addApp: "إضافة لوحة",
      composerPlaceholder: "إرسال إلى جميع اللوحات…", broadcastEmpty: "اكتب شيئًا أولاً", broadcastDone: "تم الإرسال إلى {n} لوحات ✓",
      langTip: 'لغة التطبيق', langSystem: 'النظام (لغة المتصفح)',
      gateNeed2: 'يعمل مع لوحتين أو أكثر.',
      unsupported: 'هذه المنصة غير مدعومة للتبادل بعد',
      readFail: 'فشل القراءة: ', fillFail: 'فشل الإدخال: ', sendFail: 'فشل الإرسال: ',
      filled: 'تمت تعبئة جميع حقول الإدخال',
      allDone: 'اكتمل الإدخال المتبادل + الإرسال التلقائي ✓',
      partial: 'لوحات لم تُرسل: {panels} (أعد تحميل تلك اللوحة ثم حاول مرة أخرى)',
      fail: 'فشل: ', saved: 'تم حفظ الإعدادات',
      noExportPanels: 'لا توجد لوحات مدعومة للتصدير', noConversations: 'لا توجد محادثات للقراءة',
      exportDone: 'اكتمل التصدير ✓ ({n} لوحات)', exportFail: 'فشل التصدير: ',
      langFail: 'فشل تغيير اللغة: ',
      popTitle: 'إعدادات Exchange', popTemplate: 'قالب موجه التبادل',
      popHint: 'تحل أحدث إجابات النماذج الأخرى محل {{answer}}.',
      popAutoSend: 'إرسال تلقائي', popReset: 'استعادة الافتراضي', popCancel: 'إلغاء',
      popSave: 'حفظ',
      failNoResponse: 'لا توجد إجابة', failTimeout: 'انتهت المهلة',
      failNoInput: 'لا يوجد حقل إدخال', failNoSend: 'تعذر الإرسال',
      exportTitleFull: 'AI Exchange — سجل المحادثة', exportTitleLatest: 'AI Exchange — أحدث تبادل',
      historyShow: 'سجل المحادثات (Recents)', historyHide: 'إغلاق السجل (محادثة جديدة)', historyAria: 'سجل المحادثات',
      defaultTemplate:
`فيما يلي إجابات نماذج LLM أخرى على السؤال نفسه.
قارن بينها وافحصها بدقة — بشكل نقدي ومستقل ومنفتح: بيّن ما هو صحيح وما هو خاطئ، وابحث فيما هو غير مؤكد قبل التلخيص.
لا تكتفِ بتقييم إجابات النماذج الأخرى — استفد منها لتقديم إجابة نهائية أفضل عن سؤالي الأصلي.

---
{{answer}}`
    },
    'pt-PT': {
      exchange: 'Trocar', export: 'Exportar', exportTip: 'Guardar a conversa como .md',
      exportFull: 'Conversa completa', exportLatest: 'Últimas respostas',
      settingsTip: 'Definições do Exchange', panelOpen: 'Abrir numa nova janela', panelClose: 'Fechar painel',
      panelReload: 'Recarregar painel', panelFullscreen: 'Ecrã inteiro',
      send: "Enviar", newChat: "Nova Conversa", addApp: "Adicionar painel",
      composerPlaceholder: "Enviar para todos os painéis…", broadcastEmpty: "Escreva algo primeiro", broadcastDone: "Enviado para {n} painéis ✓",
      langTip: 'Idioma da aplicação', langSystem: 'Sistema (idioma do navegador)',
      gateNeed2: 'Funciona com 2 ou mais painéis.',
      unsupported: 'Esta plataforma ainda não é suportada para troca',
      readFail: 'Falha de leitura: ', fillFail: 'Falha ao preencher: ', sendFail: 'Falha ao enviar: ',
      filled: 'Todos os campos foram preenchidos',
      allDone: 'Preenchimento cruzado + envio automático concluídos ✓',
      partial: 'Não enviado: {panels} (recarregue esse painel e tente novamente)',
      fail: 'Falha: ', saved: 'Definições guardadas',
      noExportPanels: 'Sem painéis suportados para exportar', noConversations: 'Sem conversas para ler',
      exportDone: 'Exportação concluída ✓ ({n} painéis)', exportFail: 'Falha na exportação: ',
      langFail: 'Falha ao mudar de idioma: ',
      popTitle: 'Definições do Exchange', popTemplate: 'Modelo do prompt de troca',
      popHint: 'As últimas respostas dos outros modelos substituem {{answer}}.',
      popAutoSend: 'Envio automático', popReset: 'Repor predefinição', popCancel: 'Cancelar',
      popSave: 'Guardar',
      failNoResponse: 'sem resposta', failTimeout: 'tempo esgotado',
      failNoInput: 'sem campo de entrada', failNoSend: 'não é possível enviar',
      exportTitleFull: 'AI Exchange — Registo da conversa', exportTitleLatest: 'AI Exchange — Última troca',
      historyShow: 'Histórico de conversas (Recents)', historyHide: 'Fechar histórico (nova conversa)', historyAria: 'Histórico de conversas',
      defaultTemplate:
`Seguem-se as respostas de outros LLM à mesma pergunta.
Compara-as e examina-as com rigor — de forma crítica, independente e aberta: indica o que está certo e o que está errado, e investiga o que for incerto antes de sintetizar.
Não te limites a avaliar as outras respostas — usa-as para dar uma melhor resposta final à minha pergunta original.

---
{{answer}}`
    },
    'pt-BR': {
      exchange: 'Trocar', export: 'Exportar', exportTip: 'Salvar a conversa como .md',
      exportFull: 'Conversa completa', exportLatest: 'Últimas respostas',
      settingsTip: 'Configurações do Exchange', panelOpen: 'Abrir em nova janela', panelClose: 'Fechar painel',
      panelReload: 'Recarregar painel', panelFullscreen: 'Tela cheia',
      send: "Enviar", newChat: "Nova Conversa", addApp: "Adicionar painel",
      composerPlaceholder: "Enviar para todos os painéis…", broadcastEmpty: "Digite algo primeiro", broadcastDone: "Enviado para {n} painéis ✓",
      langTip: 'Idioma do aplicativo', langSystem: 'Sistema (idioma do navegador)',
      gateNeed2: 'Funciona com 2 ou mais painéis.',
      unsupported: 'Esta plataforma ainda não é suportada para troca',
      readFail: 'Falha de leitura: ', fillFail: 'Falha ao preencher: ', sendFail: 'Falha ao enviar: ',
      filled: 'Todos os campos foram preenchidos',
      allDone: 'Preenchimento cruzado + envio automático concluídos ✓',
      partial: 'Não enviado: {panels} (recarregue esse painel e tente de novo)',
      fail: 'Falha: ', saved: 'Configurações salvas',
      noExportPanels: 'Nenhum painel suportado para exportar', noConversations: 'Nenhuma conversa para ler',
      exportDone: 'Exportação concluída ✓ ({n} painéis)', exportFail: 'Falha na exportação: ',
      langFail: 'Falha ao mudar o idioma: ',
      popTitle: 'Configurações do Exchange', popTemplate: 'Modelo do prompt de troca',
      popHint: 'As últimas respostas dos outros modelos substituem {{answer}}.',
      popAutoSend: 'Envio automático', popReset: 'Restaurar padrão', popCancel: 'Cancelar',
      popSave: 'Salvar',
      failNoResponse: 'sem resposta', failTimeout: 'tempo esgotado',
      failNoInput: 'sem campo de entrada', failNoSend: 'não foi possível enviar',
      exportTitleFull: 'AI Exchange — Registro da conversa', exportTitleLatest: 'AI Exchange — Última troca',
      historyShow: 'Histórico de conversas (Recents)', historyHide: 'Fechar histórico (nova conversa)', historyAria: 'Histórico de conversas',
      defaultTemplate:
`A seguir estão as respostas de outros LLMs à mesma pergunta.
Compare-as e examine-as com rigor — de forma crítica, independente e aberta: indique o que está certo e o que está errado, e pesquise o que for incerto antes de sintetizar.
Não se limite a avaliar as outras respostas — use-as para dar uma resposta final melhor à minha pergunta original.

---
{{answer}}`
    }
  };

  // Map a raw browser language string (e.g. 'pt', 'zh-HK', 'en-US') onto a
  // supported catalog code. Regional Chinese/Portuguese pick the closest
  // variant; any unknown language falls back to English.
  function normalize(raw) {
    const s = String(raw || '').replace('_', '-');
    if (MESSAGES[s]) return s;
    const base = s.split('-')[0].toLowerCase();
    if (base === 'zh') return /tw|hk|mo|hant/i.test(s) ? 'zh-TW' : 'zh-CN';
    if (base === 'pt') return (/-br$/i.test(s) || s.toLowerCase() === 'pt') ? 'pt-BR' : 'pt-PT';
    for (const code in MESSAGES) {
      if (code.split('-')[0].toLowerCase() === base) return code;
    }
    return 'en';
  }

  // chosen: options.language ('system' | catalog code). browserLang: raw UI
  // language string. Returns { lang, msg } with msg merged over the en base
  // so a translation gap degrades to English, never to a blank.
  function resolve(chosen, browserLang) {
    const lang = (chosen && chosen !== 'system' && MESSAGES[chosen])
      ? chosen : normalize(browserLang);
    return { lang: lang, msg: Object.assign({}, MESSAGES.en, MESSAGES[lang]) };
  }

  // Endonyms for the language menu, in menu order. Language data, so it lives
  // with the catalogs rather than in whichever page draws the menu. 'system'
  // carries no endonym; the page labels it from MSG.langSystem.
  const LANGS = [
    { value: 'system', label: '' },
    { value: 'en', label: 'English' },
    { value: 'ko', label: '한국어' },
    { value: 'ja', label: '日本語' },
    { value: 'zh-CN', label: '简体中文' },
    { value: 'zh-TW', label: '繁體中文' },
    { value: 'es', label: 'Español' },
    { value: 'fr', label: 'Français' },
    { value: 'de', label: 'Deutsch' },
    { value: 'ru', label: 'Русский' },
    { value: 'ar', label: 'العربية' },
    { value: 'pt-PT', label: 'Português (Portugal)' },
    { value: 'pt-BR', label: 'Português (Brasil)' }
  ];

  // '{key}' interpolation for the two parameterized toasts.
  function format(str, params) {
    return String(str).replace(/\{(\w+)\}/g, function (m, k) {
      return (params && k in params) ? params[k] : m;
    });
  }

  // Every localized default template — mergeSettings treats a stored template
  // equal to ANY of these as "untouched by the user" (so switching language
  // re-localizes it instead of freezing the previous language's default).
  function defaultTemplates() {
    return Object.keys(MESSAGES).map(function (k) { return MESSAGES[k].defaultTemplate; });
  }

  return { MESSAGES: MESSAGES, LANGS: LANGS, normalize: normalize, resolve: resolve, format: format, defaultTemplates: defaultTemplates };
});
