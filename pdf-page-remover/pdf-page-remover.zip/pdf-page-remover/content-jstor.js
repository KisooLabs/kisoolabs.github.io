// JSTOR Remove Cover — content script.
// Injects a "Remove cover" button next to JSTOR's Download button. On click,
// fetches the article PDF with the user's session, strips page 1 (the JSTOR cover)
// with the shared core, and hands it to the background worker to save to Downloads.
//
// Shared core (pageops.js, filename.js, pdfmeta.js, ui/toast.js) and pdf-lib are
// loaded before this file (see manifest content_scripts order); PPR.* and the
// global `PDFLib` are available in this isolated world.

(() => {
  'use strict';

  const BTN_CLASS = 'jstor-nocover-btn';
  const MARK = 'data-nocover-injected';
  const GRADIENT = 'linear-gradient(135deg, #7a0000, #ef3e44)';
  const UI_FONT = '-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif';
  const MAX_BYTES = 90 * 1024 * 1024; // ~90MB; data: URL hand-off gets unreliable beyond this

  // ------------------------------------------------------------- pdf helpers -
  function stableIdFromLocation() {
    const m = location.pathname.match(/\/stable\/(?:pdf\/)?(.+?)(?:\.pdf)?\/?$/i);
    return m ? m[1] : null;
  }
  function pdfUrl(id) {
    return location.origin + '/stable/pdf/' + id + '.pdf?acceptTC=true';
  }
  function startsWithPDF(buf) {
    const b = new Uint8Array(buf.slice(0, 5)); // %PDF-
    return b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46 && b[4] === 0x2d;
  }
  function bytesToDataUrl(bytes) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(fr.result);
      fr.onerror = () => reject(fr.error);
      fr.readAsDataURL(new Blob([bytes], { type: 'application/pdf' }));
    });
  }

  // ------------------------------------------------------------ click handler
  async function onClick(btn, doi) {
    const id = doi || stableIdFromLocation();
    if (!id) { PPR.toastErr("Couldn't find the article ID"); return; }

    btn.setAttribute('disabled', '');
    const t = PPR.toast({ spinner: true, title: 'Fetching PDF…', body: '<small>Requesting with your JSTOR session</small>' });
    try {
      const res = await fetch(pdfUrl(id), { credentials: 'include' });
      const ct = (res.headers.get('content-type') || '').toLowerCase();
      const buf = await res.arrayBuffer();

      if (!res.ok || !(ct.includes('pdf') || startsWithPDF(buf))) {
        t.remove();
        PPR.toastErr("Couldn't fetch the PDF", 'Check your login or access rights (HTTP ' + res.status + ')');
        return;
      }

      const filename = PPR.parseFilename(res.headers.get('content-disposition'), id);
      PPR.setToast(t, { spinner: true, title: 'Removing cover page…', body: '<small class="jnc-mono">' + PPR.esc(filename) + '</small>' });

      const sizes = await PPR.readPageSizes(buf);
      const total = sizes.length;
      const willRemove = total >= 2 ? [1] : [];
      const { bytes, removedCount } = willRemove.length
        ? await PPR.removePages(buf, willRemove)
        : { bytes: new Uint8Array(buf), removedCount: 0 };
      const removed = removedCount > 0;
      const pages = total;

      if (bytes.length > MAX_BYTES) {
        t.remove();
        PPR.toastErr('PDF too large to save', 'This PDF is ' + Math.round(bytes.length / 1048576) + ' MB — too large to hand off this way.');
        return;
      }

      const dataUrl = await bytesToDataUrl(bytes);
      const resp = await chrome.runtime.sendMessage({ type: 'save-pdf', dataUrl, filename });

      t.remove();
      if (resp && resp.ok) {
        const kept = removed ? pages - 1 : pages;
        const detail = (removed
          ? 'Cover removed · '
          : 'No cover found — kept original · ') + kept + ' page' + (kept === 1 ? '' : 's');
        PPR.toast({ state: 'ok', badge: '✅', title: 'Saved to Downloads',
                body: '<small class="jnc-mono">' + PPR.esc(filename) + '</small><small>' + detail + '</small>' });
      } else {
        PPR.toastErr('Save failed', (resp && resp.error) || '');
      }
    } catch (e) {
      t.remove();
      PPR.toastErr('Something went wrong', (e && e.message) ? e.message : String(e));
    } finally {
      btn.removeAttribute('disabled');
    }
  }

  // -------------------------------------------------------------- button DOM -
  // ---- rgb helpers (theme matching) ----
  function parseRgb(s) {
    const m = String(s).match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    const p = m[1].split(',').map((x) => parseFloat(x));
    return { r: p[0], g: p[1], b: p[2], a: p[3] === undefined ? 1 : p[3] };
  }
  function isTransparent(s) { const c = parseRgb(s); return !c || c.a === 0; }
  function isColored(s) {
    const c = parseRgb(s);
    if (!c || c.a === 0) return false;
    return !(c.r > 240 && c.g > 240 && c.b > 240);
  }

  // Match our button to the neighbouring JSTOR Download button:
  //  - primary (red)     -> our garnet gradient, white text
  //  - secondary (outline) -> mirror its transparent bg / dark text / light border
  // Font, padding, height, line-height and radius are mirrored either way, which
  // also keeps the "Remove cover" label vertically aligned with "Download".
  function applyStyle(btn, dl) {
    const variant = (dl.getAttribute('variant') || '').toLowerCase();
    let ref = dl, inner = null;
    try { if (dl.shadowRoot) inner = dl.shadowRoot.querySelector('#button-element, button, [part]'); } catch (_) {}
    if (inner) ref = inner;
    const cs = getComputedStyle(ref);

    const fontFamily = cs.fontFamily || UI_FONT;
    const fontSize   = (cs.fontSize && cs.fontSize !== '0px') ? cs.fontSize : '16px';
    const fontWeight = cs.fontWeight || '700';
    const lineHeight = (cs.lineHeight && cs.lineHeight !== 'normal') ? cs.lineHeight : '24px';
    const padding    = (cs.padding && cs.padding !== '0px') ? cs.padding : '4px 12px';
    const height     = (cs.height && cs.height !== 'auto' && cs.height !== '0px') ? cs.height : '33px';
    const radius     = (cs.borderTopLeftRadius && cs.borderTopLeftRadius !== '0px') ? cs.borderTopLeftRadius : '2px';
    const bw         = (cs.borderTopWidth && cs.borderTopWidth !== '0px') ? cs.borderTopWidth : '1px';

    let isPrimary;
    if (variant === 'primary') isPrimary = true;
    else if (variant === 'secondary') isPrimary = false;
    else isPrimary = isColored(cs.backgroundColor);

    let bg, color, border;
    if (isPrimary) {
      bg = GRADIENT; color = '#fff'; border = bw + ' solid transparent';
    } else {
      bg = isTransparent(cs.backgroundColor) ? 'transparent' : cs.backgroundColor;
      color = cs.color || '#000';
      border = bw + ' solid ' + (cs.borderTopColor || '#d1cfc7');
    }

    btn.dataset.ncVariant = isPrimary ? 'primary' : 'secondary';
    btn.style.cssText = [
      'box-sizing:border-box',
      'display:inline-flex', 'align-items:center', 'justify-content:center', 'gap:6px',
      'font-family:' + fontFamily, 'font-size:' + fontSize, 'font-weight:' + fontWeight, 'line-height:' + lineHeight,
      'height:' + height, 'padding:' + padding, 'margin:0',
      'border:' + border, 'border-radius:' + radius, 'color:' + color, 'background:' + bg,
      'cursor:pointer', 'vertical-align:middle', 'white-space:nowrap',
      'box-shadow:' + (isPrimary ? '0 1px 2px rgba(0,0,0,.15)' : 'none'),
      'transition:filter .15s, box-shadow .15s, transform .05s'
    ].join(';');
  }

  // Exact JSTOR "download" icon (pharos-icon name="download"), 24x24, fill follows
  // the button's text colour via currentColor — identical to JSTOR's own button.
  const ICON =
    '<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" style="flex:none">' +
    '<path d="M13 4V12.5857L17.0001 8.58564L18.4143 9.99985L12.0001 16.4141L5.58588 9.99985L7.00009 8.58564L11 12.5855V4H13Z"></path>' +
    '<path d="M20 18H4V20H20V18Z"></path></svg>';
  const LABELS = { full: 'Remove cover', short: 'Remove cover' };
  function setLabel(btn, mode) {
    if (mode === 'icon') { btn.style.gap = '0'; btn.innerHTML = ICON; }
    else { btn.style.gap = '6px'; btn.innerHTML = ICON + '<span>' + LABELS[mode] + '</span>'; }
  }

  function makeButton(dl) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = BTN_CLASS;
    btn.title = 'Download the PDF without the JSTOR cover page';
    applyStyle(btn, dl);
    setLabel(btn, 'full');
    const doi = dl.getAttribute('data-doi') || stableIdFromLocation() || '';
    btn.addEventListener('click', () => onClick(btn, doi));
    return btn;
  }

  // ---- placement: our button LEADS the Download button ----
  // Left of it in a horizontal row, above it in a vertical stack — regardless of
  // the container's flex-direction (JSTOR's main action row is row-reverse, and
  // the "Related text" items stack their buttons vertically).
  function flexChildOf(dl) {
    let node = dl.closest('[role="group"]') || dl;
    let parent = node.parentElement;
    for (let i = 0; i < 6 && parent; i++) {
      if (getComputedStyle(parent).display.indexOf('flex') >= 0) return node;
      node = parent; parent = node.parentElement;
    }
    return dl.closest('[role="group"]') || dl;
  }
  function rectOf(el) { const r = el.getBoundingClientRect(); return { top: r.top, left: r.left, h: r.height, w: r.width }; }
  function leads(o, a) {
    const sameRow = Math.abs(o.top - a.top) < Math.max(o.h, a.h) * 0.6;
    if (sameRow) return o.left < a.left - 1;
    const sameCol = Math.abs(o.left - a.left) < Math.max(o.w, a.w) * 0.6;
    if (sameCol) return o.top < a.top - 1;
    return (o.top < a.top - 1) || (Math.abs(o.top - a.top) < 2 && o.left < a.left);
  }
  function placeLeading(btn, dl) {
    const child = flexChildOf(dl);
    const ref = dl.closest('[role="group"]') || dl;
    child.insertAdjacentElement('beforebegin', btn);
    if (leads(rectOf(btn), rectOf(ref))) return;
    child.insertAdjacentElement('afterend', btn);
  }
  // The Related-text button row is narrow and wraps. Keep our button on the SAME
  // row, immediately left of Download, by shrinking the label only as much as
  // needed: "Remove cover" -> icon-only.
  function placeSecondaryInline(btn, dl) {
    const child = flexChildOf(dl);
    const ref = dl.closest('[role="group"]') || dl;
    child.insertAdjacentElement('beforebegin', btn);
    const modes = ['full', 'short', 'icon'];
    for (let i = 0; i < modes.length; i++) {
      setLabel(btn, modes[i]);
      const o = rectOf(btn), a = rectOf(ref);
      const sameRow = Math.abs(o.top - a.top) < Math.max(o.h, a.h) * 0.6;
      if (sameRow && o.left < a.left - 1) return;
    }
    setLabel(btn, 'icon'); // narrowest; leads (sits above) if even this can't fit
  }
  function alreadyInjected(child) {
    const p = child.previousElementSibling, n = child.nextElementSibling;
    return !!((p && p.classList && p.classList.contains(BTN_CLASS)) ||
              (n && n.classList && n.classList.contains(BTN_CLASS)));
  }

  function injectAll() {
    const dls = document.querySelectorAll('mfe-download-pharos-button[data-qa="download-pdf"]');
    dls.forEach((dl) => {
      if (dl.getAttribute(MARK)) return;
      const child = flexChildOf(dl);
      if (alreadyInjected(child)) { dl.setAttribute(MARK, '1'); return; }
      const btn = makeButton(dl);
      if (btn.dataset.ncVariant === 'secondary') placeSecondaryInline(btn, dl);
      else placeLeading(btn, dl);
      dl.setAttribute(MARK, '1');
    });
  }

  // ---------------------------------------------------------------- bootstrap
  try {
    injectAll();
  } catch (e) {
    console.error('[JSTOR Remove Cover] bootstrap error', e);
  }

  let pending;
  const observer = new MutationObserver(() => {
    clearTimeout(pending);
    pending = setTimeout(injectAll, 150);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener('popstate', () => setTimeout(injectAll, 150));
})();
