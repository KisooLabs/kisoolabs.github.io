// Boot and wiring for the replacement hub page. Owns the state, hands every
// feature the panels it should act on, and keeps model and view in agreement.
//
// Flow runs one way: a control calls a handler, the handler commits a new state,
// commit() persists and re-renders. Nothing reads the DOM back to find out what
// the state is, which is what the injection layer had to do.
(function () {
  const State = globalThis.AixState;
  const Panels = globalThis.AixPanels;
  const PanelBar = globalThis.AixPanelBar;
  const Header = globalThis.AixHeader;
  const Menu = globalThis.AixMenu;
  const Rpc = globalThis.AixRpc;
  const Exchange = globalThis.AixExchange;
  const Exporter = globalThis.AixExport;
  const Ui = globalThis.AixUi;
  const I18N = globalThis.CrossVerifyI18N;
  const Settings = globalThis.CrossVerifySettings;
  const core = globalThis.CrossVerifyCore;
  const sel = globalThis.CrossVerifySelectors;
  if (!State || !Panels || !PanelBar || !Header || !Menu || !Rpc || !Exchange
      || !Exporter || !Ui || !I18N || !Settings || !core || !sel) return;

  const PLATFORMS = sel.PLATFORMS;
  const KNOWN_IDS = PLATFORMS.map(function (p) { return p.id; });
  const BY_ID = Object.create(null);
  PLATFORMS.forEach(function (p) { BY_ID[p.id] = p; });

  const FALLBACK_TITLE = 'AI Exchange';
  const LANGS = I18N.LANGS;

  let state = State.DEFAULTS;
  let MSG = I18N.resolve('system', navigator.language).msg;
  let settings = core.DEFAULT_SETTINGS;
  let fullscreenId = null;

  // Single writer: persistence and re-render cannot be forgotten at a call site.
  function commit(next) {
    if (next === state) return;
    state = next;
    render();
    chrome.storage.local.set({ [State.STORAGE_KEY]: state });
  }

  function orderedPanels() {
    return Panels.inOrder(state.panels);
  }

  function i18nOpts() {
    return {
      defaultTemplate: MSG.defaultTemplate,
      knownDefaults: Object.keys(I18N.MESSAGES).map(function (c) { return I18N.MESSAGES[c].defaultTemplate; })
    };
  }

  function exchangeCtx() {
    return {
      panels: orderedPanels(), msg: MSG, settings: settings, rpc: Rpc, core: core, ui: Ui,
      defaultTemplate: MSG.defaultTemplate,
      onBusy: function (b) { Header.setExchangeBusy(b); },
      onSave: function (partial) {
        Settings.save(partial, i18nOpts()).then(function (merged) {
          settings = merged;
          Ui.toast(MSG.saved);
        });
      }
    };
  }

  const handlers = {
    broadcast: function () {
      const text = Header.getPrompt().trim();
      if (!text) { Ui.toast(MSG.broadcastEmpty); return; }
      const panels = orderedPanels();
      if (!panels.length) { Ui.toast(MSG.noExportPanels); return; }
      // Same two-phase path Exchange uses, so one panel failing cannot leave the
      // others sent. The only difference is that every panel gets the same text.
      Rpc.fillThenSend(panels, function () { return text; }).then(function (out) {
        const failLabels = {
          NO_RESPONSE: MSG.failNoResponse, TIMEOUT: MSG.failTimeout,
          NO_INPUT: MSG.failNoInput, NO_SEND: MSG.failNoSend
        };
        if (out.phase === 'fill' || out.phase === 'send') {
          const prefix = out.phase === 'fill' ? MSG.fillFail : MSG.sendFail;
          Ui.toast(prefix + core.describePanelFailures(
            out.failures.map(function (r) { return { name: r.id, error: r.error }; }), failLabels));
          return;
        }
        Header.clearPrompt();
        Ui.toast(I18N.format(MSG.broadcastDone, { n: panels.length }));
      }).catch(function (e) { Ui.toast(MSG.fail + e.message); });
    },

    exchange: function () { Exchange.run(exchangeCtx()); },

    settings: function (anchor) { Exchange.openSettings(anchor, exchangeCtx()); },

    // Every panel returns to its platform's entry URL, which is that platform's
    // new conversation.
    newChat: function () {
      orderedPanels().forEach(function (p) { p.frame.src = p.platform.url; });
    },

    exportMenu: function (anchor) {
      Menu.toggle(anchor, [
        { key: 'full', label: MSG.exportFull },
        { key: 'latest', label: MSG.exportLatest }
      ], function (scope) {
        Exporter.run({ panels: orderedPanels(), msg: MSG, rpc: Rpc, core: core, ui: Ui }, scope);
      });
    },

    addMenu: function (anchor) {
      const items = PLATFORMS.map(function (p) {
        return { key: p.id, label: p.id, checked: Panels.has(p.id), disabled: Panels.has(p.id) };
      });
      Menu.toggle(anchor, items, function (id) {
        commit(State.withPanelAdded(state, id, KNOWN_IDS));
      });
    },

    langMenu: function (anchor) {
      const items = LANGS.map(function (lang) {
        return {
          key: lang.value,
          label: lang.value === 'system' ? MSG.langSystem : lang.label,
          checked: state.language === lang.value
        };
      });
      Menu.toggle(anchor, items, function (code) { setLanguage(code); });
    }
  };

  const panelActions = {
    get labels() {
      return {
        reload: MSG.panelReload, fullscreen: MSG.panelFullscreen,
        openExternal: MSG.panelOpen, close: MSG.panelClose
      };
    },
    reload: function (id) { Panels.reload(id); },
    close: function (id) {
      if (fullscreenId === id) fullscreenId = null;
      commit(State.withPanelRemoved(state, id));
    },
    swap: function (a, b) { commit(State.withPanelsSwapped(state, a, b)); },
    toggleFullscreen: function (id) {
      fullscreenId = fullscreenId === id ? null : id;
      Panels.fullscreen(fullscreenId);
    }
  };

  function render() {
    Panels.sync(state.panels, BY_ID);
    orderedPanels().forEach(function (p) {
      if (!p.bar.dataset.aixBuilt) {
        p.bar.dataset.aixBuilt = '1';
        PanelBar.build(p, panelActions);
      }
    });
    if (fullscreenId && !Panels.has(fullscreenId)) fullscreenId = null;
    Panels.fullscreen(fullscreenId);
    document.body.classList.toggle('aix-empty', state.panels.length === 0);
    // Exchange needs two panels to have anything to cross-feed.
    const gate = core.panelGate(state.panels.length);
    Header.setExchangeEnabled(gate.enabled, MSG.gateNeed2);
    updateTitle();
  }

  // The browser tab shows the leftmost panel's conversation title. "Leftmost" is
  // the first entry in the model's array, not a measured x-coordinate.
  function updateTitle() {
    const first = orderedPanels()[0];
    const t = first && first.reportedTitle ? first.reportedTitle.trim() : '';
    const next = t || FALLBACK_TITLE;
    if (document.title !== next) document.title = next;
  }

  // Re-label the chrome in place. Panels are never touched, so switching
  // language costs no iframe reload. This replaces the React fiber walk the
  // injection layer needed to reach the vendor app's i18next instance, and the
  // location.reload() it fell back to when that walk failed.
  function setLanguage(code) {
    commit(State.withLanguage(state, code));
    MSG = I18N.resolve(state.language, navigator.language).msg;
    Header.build(document.getElementById('aix-header'), handlers, MSG);
    orderedPanels().forEach(function (p) { PanelBar.build(p, panelActions); });
    render();
    // An untouched default template follows the language; a customized one does
    // not, which is what mergeSettings decides from the known-defaults set.
    Settings.load(i18nOpts()).then(function (s) {
      settings = s;
      Settings.save(s, i18nOpts());
    });
  }

  function boot() {
    Panels.mount(document.getElementById('aix-grid'));

    Rpc.onTitle(function (win) { return Panels.bySource(win); }, function (panel, title) {
      panel.reportedTitle = title;
      panel.title.textContent = title && title.trim() ? title.trim() : panel.id;
      updateTitle();
    });

    chrome.storage.local.get(State.STORAGE_KEY, function (obj) {
      const stored = obj && obj[State.STORAGE_KEY];
      state = State.normalize(stored, KNOWN_IDS);
      MSG = I18N.resolve(state.language, navigator.language).msg;
      Header.build(document.getElementById('aix-header'), handlers, MSG);
      Settings.load(i18nOpts()).then(function (s) { settings = s; });
      render();
      if (JSON.stringify(stored) !== JSON.stringify(state)) {
        chrome.storage.local.set({ [State.STORAGE_KEY]: state });
      }
    });
  }

  globalThis.AixHub = {
    getState: function () { return state; },
    getMessages: function () { return MSG; },
    getSettings: function () { return settings; },
    platforms: PLATFORMS,
    panels: Panels,
    rpc: Rpc,
    addPanel: function (id) { commit(State.withPanelAdded(state, id, KNOWN_IDS)); },
    removePanel: function (id) { panelActions.close(id); },
    swapPanels: function (a, b) { panelActions.swap(a, b); },
    setLanguage: setLanguage
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
