(function (root) {
  // Cover detection by STABLE TEXT SIGNATURES, not page size.
  //
  // Page-size heuristics were removed deliberately: they are unreliable. A
  // repository can prepend a second cover page (e.g. an HKS working-paper title
  // page) that is the *same size* as the body, which a size rule silently
  // misses; and some documents have no cover at all. Text signatures identify a
  // cover regardless of size and work on a downloaded local file too (the text
  // lives inside the PDF), which the URL rule below cannot.
  //
  // Two high-confidence signals, unioned. We only ever pre-mark what we are sure
  // about; anything else the user marks by hand in the grid.
  //   1. TEXT detectors — run against the first few pages' extracted text.
  //   2. URL presets   — when viewing on a known site, the cover page is known.

  // Each detector recognises one known cover/banner page by text it reliably
  // contains. Keep patterns specific enough not to match body prose.
  const DETECTORS = [
    {
      id: 'dash',
      label: 'Harvard DASH cover sheet',
      re: /harvard university'?s dash repository|community has made this (?:article|work) openly available|dash\.harvard\.edu\/(?:handle|bitstream)/i,
    },
    {
      id: 'hks-frwp',
      label: 'HKS Faculty Research Working Paper title page',
      re: /faculty research working paper series/i,
    },
  ];

  const URL_PRESETS = [
    { id: 'jstor', label: 'JSTOR cover', urlRe: /^https?:\/\/(?:www\.)?jstor\.org\//i, remove: [1] },
  ];

  // Scan only the first `maxLead` pages — covers are at the front, and limiting
  // the window avoids false positives from body text (e.g. a citation that
  // quotes a working-paper series name).
  function detectCoversByText(pageTexts, maxLead) {
    const marks = new Set();
    if (!Array.isArray(pageTexts)) return marks;
    const n = Math.min(maxLead || 3, pageTexts.length);
    for (let i = 0; i < n; i++) {
      const t = pageTexts[i] || '';
      for (const d of DETECTORS) { if (d.re.test(t)) { marks.add(i + 1); break; } }
    }
    return marks;
  }

  function detectCoversByUrl(url) {
    const marks = new Set();
    if (!url) return marks;
    for (const p of URL_PRESETS) { if (p.urlRe.test(url)) p.remove.forEach((k) => marks.add(k)); }
    return marks;
  }

  // Returns a sorted array of 1-based page numbers to pre-mark for removal —
  // the union of URL-preset pages and text-signature pages. Empty when nothing
  // is confidently a cover.
  function detectCovers({ url, pageTexts } = {}) {
    const marks = new Set([...detectCoversByUrl(url), ...detectCoversByText(pageTexts, 3)]);
    return [...marks].sort((a, b) => a - b);
  }

  const api = { detectCovers, detectCoversByText, detectCoversByUrl, DETECTORS, URL_PRESETS };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.PPR = root.PPR || {}; Object.assign(root.PPR, api); }
})(typeof self !== 'undefined' ? self : globalThis);
