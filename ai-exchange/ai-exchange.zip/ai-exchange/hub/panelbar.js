// The bar above each panel: its title, its four controls, and the drag handle
// for reordering.
//
// The four controls are reload / fullscreen / open-in-new-window / close, in
// that order. On the old page only two of them were ours: the vendor rendered
// reload and fullscreen, we appended the other two, and our "close" was not an
// implementation at all but a proxy click onto a CSS-hidden vendor element. All
// four are implemented here, calling the panel API directly.
//
// Reordering swaps two panels in the model and lets the view re-render. The old
// code swapped `col.style.order` on the DOM and wrote nothing back, so the
// arrangement did not outlive the page; here the model is the only place order
// lives, so persistence is not a separate step.
(function (root, factory) {
  const api = factory();
  root.AixPanelBar = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  let dragging = null;

  function build(panel, actions) {
    const ui = globalThis.AixUi;
    panel.tools.textContent = '';
    panel.tools.appendChild(ui.iconButton('reload', actions.labels.reload, function () {
      actions.reload(panel.id);
    }));
    panel.tools.appendChild(ui.iconButton('fullscreen', actions.labels.fullscreen, function () {
      actions.toggleFullscreen(panel.id);
    }));
    panel.tools.appendChild(ui.iconButton('external', actions.labels.openExternal, function () {
      window.open(panel.platform.url, '_blank', 'noopener');
    }));
    panel.tools.appendChild(ui.iconButton('close', actions.labels.close, function () {
      actions.close(panel.id);
    }, 'aix-close'));

    wireDrag(panel, actions);
  }

  // The bar is the drag handle rather than the column, so a drag can only start
  // from chrome the user can see, never from inside a panel's own content.
  function wireDrag(panel, actions) {
    const bar = panel.bar;
    if (bar.dataset.aixDrag) return;
    bar.dataset.aixDrag = '1';
    bar.setAttribute('draggable', 'true');

    bar.addEventListener('dragstart', function (e) {
      dragging = panel.id;
      panel.col.classList.add('aix-dragging');
      try {
        e.dataTransfer.setData('text/plain', 'aix-panel');
        e.dataTransfer.effectAllowed = 'move';
      } catch (err) {}
    });
    bar.addEventListener('dragend', function () {
      panel.col.classList.remove('aix-dragging');
      const marked = document.querySelectorAll('.aix-drop-target');
      for (let i = 0; i < marked.length; i++) marked[i].classList.remove('aix-drop-target');
      dragging = null;
    });
    bar.addEventListener('dragover', function (e) {
      if (!dragging || dragging === panel.id) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      panel.col.classList.add('aix-drop-target');
    });
    bar.addEventListener('dragleave', function () {
      panel.col.classList.remove('aix-drop-target');
    });
    bar.addEventListener('drop', function (e) {
      if (!dragging || dragging === panel.id) return;
      e.preventDefault();
      panel.col.classList.remove('aix-drop-target');
      actions.swap(dragging, panel.id);
    });
  }

  return { build };
});
