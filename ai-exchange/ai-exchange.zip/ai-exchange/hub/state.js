// Persisted hub state. Pure logic: no DOM, no chrome APIs, so it runs as a
// classic browser script (attaches to globalThis.AixState) and as a CommonJS
// module (tests). Same shape as crossverify/core.js.
//
// This replaces the vendor's `options` object, whose every field encoded a
// vendor feature we are deleting: `themeMode` existed to be re-pinned to light
// by enforceLight, `colMaxCount` to be zeroed by enforceOptions, `primaryColor`
// to theme Ant Design, and `layoutPresets[].chatAppIdGroups` to implement a
// presets feature the product never surfaced. What the product actually stores
// is which panels are open, in what order, and the UI language.
//
// Panel order lives HERE, not in the DOM. The old code derived order from
// getBoundingClientRect().left because the injection layer had no access to the
// vendor's model; now order is model state that the view renders.
(function (root, factory) {
  const api = factory();
  root.AixState = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  // Own storage key. The vendor's 'options' is left untouched so the current
  // extension keeps working while this page is built beside it.
  const STORAGE_KEY = 'aix_state';

  const SCHEMA_VERSION = 1;

  const DEFAULTS = {
    v: SCHEMA_VERSION,
    panels: ['ChatGPT', 'Gemini'],
    language: 'system'
  };

  function clone(state) {
    return { v: state.v, panels: state.panels.slice(), language: state.language };
  }

  // Repair anything stored: wrong types, unknown platform ids (a platform we
  // dropped, or a hand-edited value), duplicates, empty panel list. Returns a
  // valid state every time rather than throwing, because a corrupt store must
  // not leave the user with a blank page.
  //
  // knownIds is the set of platform ids selectors.js currently supports, so
  // this module never hard-codes the platform list.
  function normalize(stored, knownIds) {
    const known = knownIds && knownIds.length ? knownIds : DEFAULTS.panels;
    const s = (stored && typeof stored === 'object') ? stored : {};
    const seen = Object.create(null);
    const panels = [];
    const raw = Array.isArray(s.panels) ? s.panels : [];
    for (let i = 0; i < raw.length; i++) {
      const id = raw[i];
      if (typeof id !== 'string') continue;
      if (known.indexOf(id) === -1) continue;
      if (seen[id]) continue;
      seen[id] = true;
      panels.push(id);
    }
    if (!panels.length) {
      // Fall back to the first two supported platforms rather than to the
      // literal default ids, which may no longer be supported.
      for (let i = 0; i < known.length && panels.length < 2; i++) panels.push(known[i]);
    }
    return {
      v: SCHEMA_VERSION,
      panels: panels,
      language: typeof s.language === 'string' && s.language ? s.language : DEFAULTS.language
    };
  }

  function withPanelAdded(state, id, knownIds) {
    const known = knownIds && knownIds.length ? knownIds : [];
    if (known.indexOf(id) === -1) return state;
    if (state.panels.indexOf(id) !== -1) return state;
    const next = clone(state);
    next.panels.push(id);
    return next;
  }

  // Removing the last panel is allowed: the header stays usable and the user
  // can add one back. Exchange gates itself on panel count separately.
  function withPanelRemoved(state, id) {
    const i = state.panels.indexOf(id);
    if (i === -1) return state;
    const next = clone(state);
    next.panels.splice(i, 1);
    return next;
  }

  // Swap two panels' positions. Swap, not move-before, because that is what the
  // current drag-and-drop does and the rewrite is not changing user-visible
  // behavior. Unknown ids leave the state alone.
  function withPanelsSwapped(state, aId, bId) {
    const i = state.panels.indexOf(aId);
    const j = state.panels.indexOf(bId);
    if (i === -1 || j === -1 || i === j) return state;
    const next = clone(state);
    next.panels[i] = bId;
    next.panels[j] = aId;
    return next;
  }

  function withLanguage(state, language) {
    if (typeof language !== 'string' || !language) return state;
    if (state.language === language) return state;
    const next = clone(state);
    next.language = language;
    return next;
  }

  return {
    STORAGE_KEY, SCHEMA_VERSION, DEFAULTS,
    normalize, withPanelAdded, withPanelRemoved, withPanelsSwapped, withLanguage
  };
});
