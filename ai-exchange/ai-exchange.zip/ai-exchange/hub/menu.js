// One dropdown, used by the add-panel list, the export scopes, and the language
// picker. Rendered into document.body at fixed coordinates rather than inside
// the button, so it is never clipped by a header with overflow, and there is at
// most one open at a time.
(function (root, factory) {
  const api = factory();
  root.AixMenu = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const ID = 'aix-menu';
  let closer = null;

  function close() {
    const el = document.getElementById(ID);
    if (el) el.remove();
    if (closer) {
      document.removeEventListener('mousedown', closer);
      document.removeEventListener('keydown', closer);
      closer = null;
    }
  }

  function isOpen() {
    return !!document.getElementById(ID);
  }

  // items: [{ key, label, checked, disabled }]. onPick receives the key.
  function open(anchor, items, onPick) {
    close();
    const el = document.createElement('div');
    el.id = ID;
    el.className = 'aix-menu';
    el.setAttribute('role', 'menu');

    items.forEach(function (item) {
      const row = document.createElement('button');
      row.type = 'button';
      row.className = 'aix-menu-row' + (item.checked ? ' aix-checked' : '');
      row.setAttribute('role', 'menuitem');
      row.disabled = !!item.disabled;
      const mark = document.createElement('span');
      mark.className = 'aix-menu-mark';
      mark.textContent = item.checked ? '✓' : '';
      row.appendChild(mark);
      row.appendChild(document.createTextNode(item.label));
      row.addEventListener('click', function () {
        close();
        onPick(item.key);
      });
      el.appendChild(row);
    });

    document.body.appendChild(el);

    // Place under the anchor, pulled back inside the viewport when the anchor
    // sits near the right edge.
    const r = anchor.getBoundingClientRect();
    const w = el.offsetWidth;
    const left = Math.max(8, Math.min(r.left, window.innerWidth - w - 8));
    el.style.left = left + 'px';
    el.style.top = (r.bottom + 6) + 'px';

    // Deferred so the click that opened the menu does not immediately close it.
    setTimeout(function () {
      closer = function (e) {
        if (e.type === 'keydown' && e.key !== 'Escape') return;
        if (e.type === 'mousedown' && (el.contains(e.target) || anchor.contains(e.target))) return;
        close();
      };
      document.addEventListener('mousedown', closer);
      document.addEventListener('keydown', closer);
    }, 0);

    return el;
  }

  // Open unless this same anchor already has it open, which makes a button
  // click toggle rather than reopen.
  function toggle(anchor, items, onPick) {
    if (isOpen() && document.getElementById(ID).dataset.anchor === anchorKey(anchor)) {
      close();
      return null;
    }
    const el = open(anchor, items, onPick);
    el.dataset.anchor = anchorKey(anchor);
    return el;
  }

  function anchorKey(anchor) {
    return anchor.id || anchor.className;
  }

  return { open, toggle, close, isOpen };
});
