(function (root) {
  async function readPageSizes(bytes) {
    const doc = await PDFLib.PDFDocument.load(bytes, { ignoreEncryption: true });
    return doc.getPages().map((p) => {
      const { width, height } = p.getSize();
      return { w: Math.round(width), h: Math.round(height) };
    });
  }
  const api = { readPageSizes };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.PPR = root.PPR || {}; root.PPR.readPageSizes = readPageSizes; }
})(typeof self !== 'undefined' ? self : globalThis);
