// Remove a set of 1-indexed pages from PDF bytes. Non-destructive: returns new bytes.
(function (root) {
  async function removePages(bytes, pages1) {
    const doc = await PDFLib.PDFDocument.load(bytes, { ignoreEncryption: true });
    const total = doc.getPageCount();
    // normalize: unique, in-range, 1-indexed -> sorted DESC so indices stay valid
    const targets = [...new Set(pages1)]
      .filter((n) => Number.isInteger(n) && n >= 1 && n <= total)
      .sort((a, b) => b - a);
    if (targets.length >= total) throw new Error('cannot remove every page');
    targets.forEach((n) => doc.removePage(n - 1));
    const out = await doc.save();
    return { bytes: out, removedCount: targets.length, total };
  }

  const api = { removePages };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.PPR = root.PPR || {}; root.PPR.removePages = removePages; }
})(typeof self !== 'undefined' ? self : globalThis);
