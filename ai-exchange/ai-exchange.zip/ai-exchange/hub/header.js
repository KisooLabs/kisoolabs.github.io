// The header. Controls are built here and their handlers are passed in, so
// nothing has to locate a button by translated text or by an icon class the way
// the injection layer did: those lookups existed only because the header
// belonged to someone else.
//
// Order is Send / [Exchange | gear] / New Chat / Export, with the brand and the
// broadcast composer to their left and the add-panel and language controls to
// their right. That order is the product's, recorded in the smoke checklist.
(function (root, factory) {
  const api = factory();
  root.AixHeader = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const ui = () => globalThis.AixUi;
  const menu = () => globalThis.AixMenu;

  let els = null;

  function build(hostEl, handlers, msg) {
    hostEl.textContent = '';

    const brand = document.createElement('div');
    brand.className = 'aix-brand';
    brand.appendChild(ui().brandMark(28));
    const word = document.createElement('span');
    word.className = 'aix-wordmark';
    word.textContent = 'AI Exchange';
    brand.appendChild(word);

    // Broadcast composer. Enter submits, Shift+Enter adds a line, which is what
    // every panel's own composer does.
    const composerWrap = document.createElement('div');
    composerWrap.className = 'aix-composer';
    const input = document.createElement('textarea');
    input.id = 'aix-composer-input';
    input.rows = 1;
    input.placeholder = msg.composerPlaceholder;
    input.addEventListener('input', function () { autosize(input); });
    // Wrapping depends on the available width, so the height has to be
    // recomputed when the window changes size, not only when the text does.
    window.addEventListener('resize', function () { autosize(input); });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
        e.preventDefault();
        handlers.broadcast();
      }
    });
    composerWrap.appendChild(input);

    const sendBtn = ui().textButton('send', msg.send, handlers.broadcast, 'aix-send');

    // Split control: the main segment only runs the exchange, the gear only
    // opens settings. Neither opens the other's surface.
    const exchangeGroup = document.createElement('div');
    exchangeGroup.className = 'aix-split';
    const exchangeBtn = ui().textButton('exchange', msg.exchange, handlers.exchange, 'aix-exchange');
    exchangeBtn.id = 'aix-exchange-btn';
    const gearBtn = ui().iconButton('gear', msg.settingsTip, function () {
      handlers.settings(gearBtn);
    }, 'aix-gear');
    gearBtn.id = 'aix-gear-btn';
    exchangeGroup.appendChild(exchangeBtn);
    exchangeGroup.appendChild(gearBtn);

    const newChatBtn = ui().textButton('edit', msg.newChat, handlers.newChat, 'aix-newchat');

    const exportBtn = ui().textButton('download', msg.export, function () {
      handlers.exportMenu(exportBtn);
    }, 'aix-export');
    exportBtn.id = 'aix-export-btn';
    exportBtn.title = msg.exportTip;

    const addBtn = ui().iconButton('plus', msg.addApp, function () {
      handlers.addMenu(addBtn);
    }, 'aix-add');
    addBtn.id = 'aix-add-btn';

    const langBtn = ui().iconButton('globe', msg.langTip, function () {
      handlers.langMenu(langBtn);
    }, 'aix-lang');
    langBtn.id = 'aix-lang-btn';

    const right = document.createElement('div');
    right.className = 'aix-header-right';
    right.appendChild(addBtn);
    right.appendChild(langBtn);

    // Three zones, not one flat row: brand, then the composer with the actions
    // that operate on what is typed, then the two controls that configure the
    // page. Grouping is what creates the space between them; a single gap value
    // across seven controls reads as one crowded strip.
    const actions = document.createElement('div');
    actions.className = 'aix-actions';
    actions.appendChild(sendBtn);
    actions.appendChild(exchangeGroup);
    actions.appendChild(newChatBtn);
    actions.appendChild(exportBtn);

    hostEl.appendChild(brand);
    hostEl.appendChild(composerWrap);
    hostEl.appendChild(actions);
    hostEl.appendChild(right);

    els = { input, sendBtn, exchangeBtn, gearBtn, newChatBtn, exportBtn, addBtn, langBtn };
    // Measurable only once it is in the document.
    autosize(input);
    return els;
  }

  const MAX_H = 220;

  // Height arithmetic, kept separate so it can be checked without a browser.
  //
  // The textarea is border-box (the page sets `* { box-sizing: border-box }`),
  // and `scrollHeight` counts content plus padding but NOT the border. Setting
  // the height to `scrollHeight` alone therefore leaves the border unpaid for,
  // the content overflows by exactly the border width, and a scrollbar appears
  // even on a single line. Adding the border back is what removes it.
  //
  // The scrollbar is also not wanted until the box actually stops growing, so
  // overflow stays hidden until the cap is reached.
  function sizeFor(scrollHeight, borderY, maxH) {
    const wanted = scrollHeight + borderY;
    return {
      height: Math.min(wanted, maxH),
      overflowY: wanted > maxH ? 'auto' : 'hidden'
    };
  }

  function borderYOf(input) {
    const cs = window.getComputedStyle(input);
    return (parseFloat(cs.borderTopWidth) || 0) + (parseFloat(cs.borderBottomWidth) || 0);
  }

  function autosize(input) {
    // Collapse first: scrollHeight of an already-tall box reports the old
    // height, so it would never shrink when text is deleted.
    input.style.height = 'auto';
    const out = sizeFor(input.scrollHeight, borderYOf(input), MAX_H);
    input.style.height = out.height + 'px';
    input.style.overflowY = out.overflowY;
    // Anything taller than one line hangs below the header, over the panels.
    const restH = parseFloat(window.getComputedStyle(input).minHeight) || 0;
    input.classList.toggle('aix-grown', out.height > restH);
  }

  function getPrompt() {
    return els ? els.input.value : '';
  }

  function clearPrompt() {
    if (!els) return;
    els.input.value = '';
    autosize(els.input);
  }

  // Exchange can occupy the page for tens of seconds on a long conversation, and
  // a control that looks idle that long invites a second click. Disabling is not
  // enough on its own: a frozen button reads as broken, so it also pulses.
  function setExchangeBusy(busy) {
    if (!els) return;
    els.exchangeBtn.classList.toggle('aix-busy', busy);
    els.exchangeBtn.disabled = busy;
  }

  function setExchangeEnabled(enabled, reason) {
    if (!els) return;
    els.exchangeBtn.disabled = !enabled;
    els.exchangeBtn.title = enabled ? '' : (reason || '');
  }

  function focusComposer() {
    if (els) els.input.focus();
  }

  return { build, getPrompt, clearPrompt, setExchangeBusy, setExchangeEnabled, focusComposer, sizeFor, MAX_H, close: () => menu().close() };
});
