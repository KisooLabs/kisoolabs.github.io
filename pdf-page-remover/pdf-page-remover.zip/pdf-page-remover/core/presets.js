(function (root) {
  function wildcardToRegExp(pattern) {
    const esc = pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
    return new RegExp('^' + esc + '$', 'i');
  }
  function page1DiffersFromBody(pageSizes) {
    if (!pageSizes || pageSizes.length < 2) return false;
    const key = (s) => s.w + 'x' + s.h;
    const counts = {};
    for (let i = 1; i < pageSizes.length; i++) { const k = key(pageSizes[i]); counts[k] = (counts[k] || 0) + 1; }
    const bodyKey = Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0];
    return key(pageSizes[0]) !== bodyKey;
  }

  const PRESETS = [
    {
      id: 'jstor',
      label: 'JSTOR cover',
      match: { urlPattern: '*://www.jstor.org/*', pageSizeRule: 'page1-differs' },
      action: { remove: [1] },
      entry: ['popup-suggest', 'onpage-button']
    }
  ];

  function matchPreset({ url, pageSizes }) {
    for (const p of PRESETS) {
      const byUrl = p.match.urlPattern && url && wildcardToRegExp(p.match.urlPattern).test(url);
      const bySize = p.match.pageSizeRule === 'page1-differs' && page1DiffersFromBody(pageSizes) && url && url.startsWith('file://');
      if (byUrl || bySize) return p;
    }
    if (page1DiffersFromBody(pageSizes)) {
      return { id: 'generic-size', label: 'Different-sized first page',
               match: { pageSizeRule: 'page1-differs' }, action: { remove: [1] }, entry: ['popup-suggest'] };
    }
    return null;
  }

  const api = { PRESETS, matchPreset, page1DiffersFromBody };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.PPR = root.PPR || {}; Object.assign(root.PPR, api); }
})(typeof self !== 'undefined' ? self : globalThis);
