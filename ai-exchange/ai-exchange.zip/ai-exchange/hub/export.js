// Export the panels' conversations as one markdown file, in either scope: the
// full history of every panel, or just each panel's latest answer.
//
// The document is assembled by core.buildConversationMarkdown, which is carried
// over unchanged. Panels arrive in the model's order, so the file's section
// order matches what the user sees left to right.
(function (root, factory) {
  const api = factory();
  root.AixExport = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  function dateStamp() {
    const d = new Date();
    const pad = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  function download(filename, text) {
    const blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  // scope: 'full' reads every turn of every panel; 'latest' reads one assistant
  // turn per panel. A panel that fails to read is left out of the file rather
  // than aborting the export, because a partial log is still worth having.
  function run(ctx, scope) {
    const panels = ctx.panels;
    const msg = ctx.msg;
    if (!panels.length) {
      ctx.ui.toast(msg.noExportPanels);
      return Promise.resolve(null);
    }
    const action = scope === 'full' ? 'READ_CONVERSATION' : 'READ_RESPONSE';
    return ctx.rpc.each(panels, action, {}).then(function (results) {
      const out = [];
      results.forEach(function (r) {
        if (!r.ok || !r.data) return;
        const turns = scope === 'full'
          ? (r.data.turns || [])
          : [{ role: 'assistant', text: r.data.text }];
        if (turns.length) out.push({ platform: r.id, turns: turns });
      });
      if (!out.length) {
        ctx.ui.toast(msg.noConversations);
        return null;
      }
      const md = ctx.core.buildConversationMarkdown(out, {
        title: scope === 'full' ? msg.exportTitleFull : msg.exportTitleLatest,
        exportedAt: new Date().toLocaleString()
      });
      download('ai-exchange-' + dateStamp() + '.md', md);
      ctx.ui.toast(globalThis.CrossVerifyI18N.format(msg.exportDone, { n: out.length }));
      return md;
    }).catch(function (e) {
      ctx.ui.toast(msg.exportFail + e.message);
      return null;
    });
  }

  return { run, dateStamp };
});
