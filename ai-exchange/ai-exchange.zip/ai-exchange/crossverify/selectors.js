// Data only. The single place that breaks when a site changes its DOM.
//
// `url` is the page a panel opens. It lived in the vendor bundle's 30-app
// catalog (chunk-a682ba63.js), which is being deleted; the four values were
// read out of it and moved here so the panel list has one owner.
(function (root, factory) {
  const api = factory();
  root.CrossVerifySelectors = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const PLATFORMS = [
    {
      id: 'ChatGPT',
      hostSuffix: 'chatgpt.com',
      url: 'https://chatgpt.com/',
      // Two DOMs are live at once, per account (measured 2026-09-25). The
      // older one marks every turn with data-message-author-role and gives the
      // composer id="prompt-textarea". The newer app-shell DOM has neither:
      // its composer is a ProseMirror carrying data-composer-markdown (with no
      // id) inside a form carrying data-thread-find-composer, the send button
      // is that form's type=submit button (no data-testid anywhere on the
      // page), a user turn is [data-user-message-bubble] and an answer body is
      // [data-markdown-text-style="assistant-message"]. Each selector below
      // names the old element first and the new one second, so both DOMs work.
      // The new form's data-chatgpt-composer is on the new-chat page only, and
      // the send button's aria-label is localized, so neither is used.
      inputSelector: '#prompt-textarea, [data-composer-markdown][contenteditable="true"]',
      inputMethod: 'contenteditable',
      sendButtonSelector: '[data-testid="send-button"], form[data-thread-find-composer] button[type="submit"]',
      responseSelector: '[data-message-author-role="assistant"], [data-markdown-text-style="assistant-message"]',
      responseTextSelector: '.markdown',
      // Full-conversation export. In the older DOM every turn (user +
      // assistant) carries a role attribute, so one selector walks the whole
      // thread in document order. In the newer DOM there is no role attribute,
      // so the user bubble and the answer body are named directly; they
      // interleave in document order the same way. A node with the attribute
      // takes its role from it, any other from userTurnSelector.
      turnSelector: '[data-message-author-role], [data-user-message-bubble], [data-markdown-text-style="assistant-message"]',
      turnRoleAttr: 'data-message-author-role',
      userTurnSelector: '[data-user-message-bubble]'
    },
    {
      id: 'Gemini',
      hostSuffix: 'gemini.google.com',
      url: 'https://gemini.google.com/app',
      inputSelector: 'rich-textarea .ql-editor[contenteditable="true"]',
      inputMethod: 'contenteditable',
      sendButtonSelector: 'button[aria-label*="Send" i]',
      responseSelector: 'message-content',
      responseTextSelector: '.markdown',
      // Full-conversation export: user turns are <user-query>, model turns
      // <message-content>; together they interleave in document order.
      // (Gemini's DOM is the fragile one here — validate in the smoke test.)
      turnSelector: 'user-query, message-content',
      userTurnSelector: 'user-query',
      // A <user-query>'s innerText opens with a screen-reader label that
      // repeats the prompt in TRUNCATED form ("You said Below are other LLMs'
      // answers … criti…"), so reading the turn whole exported every Gemini
      // prompt twice, the first copy cut off mid-word. The label is an
      // <h5 class="cdk-visually-hidden screen-reader-user-query-label"> beside
      // the visible <p class="query-text-line"> paragraphs; taking the
      // paragraphs is what leaves the label out. One <p> per line, so they join
      // on a newline. Live-verified 2026-08-28 (18 lines, 2586 chars, no "You
      // said" prefix). Absent this class the export falls back to innerText,
      // i.e. to the old behavior rather than to nothing.
      userTextSelector: '.query-text-line'
    },
    {
      // claude.ai renders a stripped "embedded mode" inside our frame (no
      // sidebar — see crossverify/claude-history.js), but the composer and the
      // rendered answers are present, so cross-verify works. Selectors below
      // were live-verified in the embedded frame (probe13/14, 2026-07-17).
      id: 'Claude',
      hostSuffix: 'claude.ai',
      url: 'https://claude.ai/',
      inputSelector: 'div.ProseMirror[contenteditable="true"]',
      inputMethod: 'contenteditable',
      // Only mounts once the composer holds text (type="button", no testid) —
      // agent.js writes first, then its 150ms settle finds the button.
      sendButtonSelector: 'button[aria-label*="Send" i]',
      // One node per assistant message, not nested, clean innerText. The old
      // .font-claude-message is gone from the DOM (0 matches = the "답변 없음"
      // abort), and .font-claude-response-body is fragmented per markdown
      // block (38 nodes for 3 answers) — use neither. [data-is-streaming]
      // wraps each answer but its innerText carries a "Claude responded:"
      // a11y prefix, so it must not be a text source.
      responseSelector: '.font-claude-response',
      // Full-conversation export: user turns carry a data-testid, model turns
      // are .font-claude-response; together they interleave in document order.
      turnSelector: '[data-testid="user-message"], .font-claude-response',
      userTurnSelector: '[data-testid="user-message"]'
    },
    {
      // grok.com standalone web app. Grok tags author by container position
      // rather than a stable role attribute, so export treats every bubble as
      // an assistant turn (no userTurnSelector). Cross-verify only needs the
      // latest answer, which responseSelector covers.
      //
      // Live-verified in the LOGGED-IN panel frame via CDP-attach to a real
      // Chrome (2026-07-18; X blocks login in a Playwright-launched browser, so
      // the earlier automated probes only ever saw the logged-out landing page):
      //  - The panel iframe DOES inherit a grok.com login (no third-party-frame
      //    auth block), so cross-verify is viable in-panel.
      //  - The composer is a Tiptap/ProseMirror contenteditable, NOT a textarea;
      //    the original `textarea`/`inputMethod:'textarea'` filled a phantom
      //    element and left Grok's real input empty. Fill via execCommand lands.
      //  - The send button is `[data-testid="chat-submit"]`. An aria-label
      //    "Submit" button exists ONLY on the logged-out landing page — in the
      //    real app `button[aria-label*="Submit" i]` matches ZERO, so the
      //    testid is the only working hook. (The original broad
      //    `button[type="submit"]` also matched the OneTrust cookie banner.)
      //  - User turns carry `[data-testid="user-message"]`, so Grok DOES have a
      //    per-turn author marker (the earlier "no stable marker" note was wrong)
      //    — used as userTurnSelector so export can split roles.
      //
      //  - Answers: `[data-testid="assistant-message"]` IS the assistant's
      //    `.message-bubble` element, and it CONTAINS a clean
      //    `.response-content-markdown` body — the same container/body split
      //    ChatGPT uses. Rejected `.message-bubble` as responseSelector: it also
      //    matches USER turns, and its innerText carries Grok's reasoning
      //    prefix ("1s동안 생각함") which would pollute both the exchange payload
      //    and the .md export — the same trap Claude's `[data-is-streaming]`
      //    hit. `.response-content-markdown` yields the answer text alone.
      //  - Full export: `.message-bubble` walks both roles in document order
      //    (user + assistant), split by userTurnSelector; turnText() reads each
      //    bubble's `.response-content-markdown`, so both roles come out clean.
      id: 'Grok',
      hostSuffix: 'grok.com',
      url: 'https://grok.com/',
      inputSelector: 'div.ProseMirror[contenteditable="true"]',
      inputMethod: 'contenteditable',
      sendButtonSelector: '[data-testid="chat-submit"]',
      responseSelector: '[data-testid="assistant-message"]',
      responseTextSelector: '.response-content-markdown',
      turnSelector: '.message-bubble',
      userTurnSelector: '[data-testid="user-message"]'
    }
  ];

  // Localized labels for locating the header Send button in any UI language.
  // Extracted from the vendor bundle's i18n (header.sendButton entries) back when
  // the Send button belonged to that bundle and had to be found by its text.
  // The bundle is gone; these strings now live in i18n.js as MSG.send, and this
  // table is kept only as the record of where they came from.
  const SEND_LABELS = [
    'Send',       // en
    '보내기',     // ko
    'Enviar',     // es/pt
    'Envoyer',    // fr
    'Senden',     // de
    'Отправить',  // ru
    'إرسال',      // ar
    '发送',       // zh-Hans
    '發送',       // zh-Hant
    '送信'        // ja
  ];

  // Same origin as SEND_LABELS above; now i18n.js MSG.newChat.
  const NEWCHAT_LABELS = [
    'New Chat',         // en
    '새 채팅',          // ko
    'Neuer Chat',       // de
    'Nouveau Chat',     // fr
    'Nova Conversa',    // pt
    'Nuevo Chat',       // es
    'Новый чат',        // ru
    'دردشة جديدة',      // ar
    '新しいチャット',   // ja
    '新对话',           // zh-Hans
    '新聊天'            // zh-Hant
  ];

  return { PLATFORMS, SEND_LABELS, NEWCHAT_LABELS };
});
