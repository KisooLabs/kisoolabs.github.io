// Background service worker. It has one job: open the hub page when the toolbar
// icon is clicked.
//
// Everything the vendor's worker did beyond that is gone by design. It
// registered content scripts at runtime through `chrome.scripting`, which is
// why eight bundle chunks had to be web-accessible to every http(s) origin;
// ours are declared statically in the manifest instead, so that exposure has no
// reason to exist. It also rebuilt the declarativeNetRequest rules on every
// start, duplicating the static ruleset in `rules/embed.json` for the four
// panel domains and adding rules for two dozen more that host permissions made
// inert. The static ruleset is the whole of it now.
const HUB_PAGE = 'hub/index.html';

// Reuse an open hub rather than stacking another one: each hub holds up to four
// cross-origin panels, so a second copy is expensive and never wanted.
async function openHub() {
  const url = chrome.runtime.getURL(HUB_PAGE);
  const existing = await chrome.tabs.query({ url: url });
  if (existing && existing.length) {
    await chrome.tabs.update(existing[0].id, { active: true });
    await chrome.windows.update(existing[0].windowId, { focused: true });
    return;
  }
  await chrome.tabs.create({ url: url });
}

chrome.action.onClicked.addListener(function () {
  openHub();
});
