// Background service worker. Two jobs:
//
// (1) Save a produced PDF (data: URL) to Downloads. Popup and content scripts
//     cannot always call chrome.downloads directly, so they hand the finished
//     PDF here and we download it with no Save-As dialog.
//
// (2) Register the JSTOR content script *dynamically*, only while the optional
//     jstor.org host permission is granted. A static content_scripts entry on a
//     host that lives in optional_host_permissions is unreliable in Chrome MV3
//     (it can force the host into the install-time permission warning, or never
//     inject after a runtime grant). Dynamic registration via chrome.scripting
//     keeps the base install host-permission-free and makes JSTOR fully opt-in
//     and revocable (see DECISIONS 2026-07-02).

const JSTOR_ORIGIN = 'https://www.jstor.org/*';
const JSTOR_SCRIPT = {
  id: 'jstor-cover',
  matches: ['https://www.jstor.org/stable/*'],
  js: ['core/pageops.js', 'core/filename.js', 'core/pdfmeta.js', 'ui/toast.js', 'lib/pdf-lib.min.js', 'content-jstor.js'],
  runAt: 'document_idle'
};

// Reconcile the registered content script with the current permission state:
// register when jstor.org is granted and not yet registered, unregister when the
// permission is gone. Idempotent — safe to run on any of the events below.
async function syncJstorScript() {
  let has = false;
  try { has = await chrome.permissions.contains({ origins: [JSTOR_ORIGIN] }); } catch (_) {}
  let registered = false;
  try {
    const cur = await chrome.scripting.getRegisteredContentScripts({ ids: [JSTOR_SCRIPT.id] });
    registered = cur.some((s) => s.id === JSTOR_SCRIPT.id);
  } catch (_) {}
  try {
    if (has && !registered) await chrome.scripting.registerContentScripts([JSTOR_SCRIPT]);
    else if (!has && registered) await chrome.scripting.unregisterContentScripts({ ids: [JSTOR_SCRIPT.id] });
  } catch (e) {
    console.error('[PDF Page Remover] content-script sync failed', e);
  }
}

chrome.runtime.onInstalled.addListener(syncJstorScript);
chrome.runtime.onStartup.addListener(syncJstorScript);
chrome.permissions.onAdded.addListener(syncJstorScript);
chrome.permissions.onRemoved.addListener(syncJstorScript);

// Save a produced PDF (data: URL) to Downloads.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== 'save-pdf') return;
  chrome.downloads.download(
    { url: msg.dataUrl, filename: msg.filename, saveAs: false, conflictAction: 'uniquify' },
    (downloadId) => {
      if (chrome.runtime.lastError || downloadId === undefined) {
        sendResponse({ ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'download failed' });
      } else {
        sendResponse({ ok: true, downloadId });
      }
    }
  );
  return true; // async response
});
